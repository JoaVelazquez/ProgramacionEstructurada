#include <stdio.h>
#include <stdlib.h>
void DecideOperacion(char,int,int);
void Suma(int a,int b);
void Resta(int a,int b);
void Producto(int a,int b);
void Division(int a,int b);

int main()
{
    printf("Ingrese primer numero: ");
    int a = 0 ;
    scanf("%d", &a);
    printf("\nIngrese segundo numero: ");
    int b = 0;
    scanf("%d", &b);
    printf("\nIngrese la operacion [+ - * /]: ");
    char op = getche();
    DecideOperacion(op,a,b);

    return 0;
}
void DecideOperacion(char c, int a, int b){
    if( c == '+'){
        Suma(a,b);
    }
    else if( c == '-'){
        Resta(a,b);
    }
    else if( c == '*'){
        Producto(a,b);
    }
    else if( c == '/'){
        Division(a,b);
    }
}
void Suma(int a, int b){
    printf("\nSuma = %d",a+b);
}
void Resta(int a, int b){
    printf("\nResta = %d",a-b);
}
void Producto(int a, int b){
    printf("\nProducto = %d",a*b);
}
void Division(int a, int b){
    printf("\nDivision = %d",a/b);
}
