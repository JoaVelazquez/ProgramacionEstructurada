#include <stdio.h>
#include <stdlib.h>
#define F 25
#define C 25
int main()
{
    char nombre;
    char mat[F][C];
    nombre = "Equipos.txt";
    cargarMatTxtDeArch(mat,nombre);
    imprimirMatTxt(mat);
    return 0;
}
void cargarMatTxtDeArch(char mat[F][C], char nombre){

    char ch;
    int f,c;
    FILE* archivo;
    archivo = fopen("Equipos.txt","r");
    ch = fgetc(archivo);

    for( f = 0 ; f<F ; f++){
        for ( c = 0 ; c<C && ch!="\n" ; c++){
            mat[f][c] = ch;
            ch = fgetc(archivo);
        }
    }
    fclose(archivo);
}

void imprimirMatTxt(char mat[F][C]){

    int f,c;

    for( f=0 ; f<F ; f++){
        for( c=0 ; c<C ; c++){
            printf("%c", mat[f][c]);
        }
    }

}
