#define N 25
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define F 25
#define C 25
int main()
{
    char nombre;
    char mat[F][C];
    nombre = "Equipos.txt";
    cargarMatTxtDeArch(mat,nombre);
    imprimirMatTxt(mat);
    ordenarTexto(mat);
    imprimirMatTxt(mat);
    return 0;
}
void cargarMatTxtDeArch(char mat[F][C], char nombre){

    printf("------------CARGA ARCH---------\n");
    char ch;
    int f,c;

    FILE* archivo;
    archivo = fopen("Equipos.txt","r");
    ch = fgetc(archivo);

    for( f = 0 ; (ch!=EOF) && (f<F-1) ; f++){
        for ( c = 0 ; (ch!=EOF) && (c<C-1) && (ch!='\n') ; c++){

            printf("%c",ch);
            mat[f][c] = ch;
            ch = fgetc(archivo);
        }

        mat[f][c] = '\0';
        ch = fgetc(archivo);
        printf("\n");
    }
    mat[f][0] = '\0';
    fclose(archivo);
}

void imprimirMatTxt(char mat[F][C]){

    printf("\n-------------IMPRIME------------\n");
    int f,c;

    for( f=0 ; mat[f][0]!='\0' && f<F ; f++){
        for( c=0 ; mat[f][c]!='\0' && c<C ; c++){
            printf("%c", mat[f][c]);
        }
        printf("\n");
    }
}

void ordenarTexto(char mat[][N]){

    printf("\n-------------ORDENA-------------\n");
    int f,j;
    char aux[F];
    for( f=0 ; mat[f][0]!='\0' && f<F ; f++){
        for(j=0 ; mat[j][0]!='\0' && j<F ;  j++){
            if(strcmp(mat[f],mat[j])){

                strcpy(aux,mat[f]);
                strcpy(mat[f],mat[j]);
                strcpy(mat[j],aux);

            }
        }
    }

}
