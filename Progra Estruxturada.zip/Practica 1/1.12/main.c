#include <stdio.h>
#include <stdlib.h>
#define F 5
#define C 8
int main()
{
    int mat[F][C];
    printf("---------CARGA----------\n");
    CargaMatIntDeArch(mat,"datos.txt");
    printf("--------IMPRIME---------\n");
    ImprimeMatInt(mat);
    return 0;
}
int CargaMatIntDeArch(int mat[F][C],char nombre[]){

    int f;
    FILE* archivo;
    archivo = fopen(nombre,"r");

    if( archivo == NULL){
        printf("El archivo esta vacio.\n");
        return -1;
    }
    int n0,n1,n2,n3,n4,n5,n6,n7;
    for( f=0 ; (f<F) && (fscanf(archivo,"%d,%d,%d,%d,%d,%d,%d,%d",&n0,&n1,&n2,&n3,&n4,&n5,&n6,&n7) != EOF) ; f++){
   // printf("\n%d,%d,%d,%d,%d,%d,%d,%d\n",n0,n1,n2,n3,n4,n5,n6,n7);
        mat[f][0]=n0;
        mat[f][1]=n1;
        mat[f][2]=n2;
        mat[f][3]=n3;
        mat[f][4]=n4;
        mat[f][5]=n5;
        mat[f][6]=n6;
        mat[f][7]=n7;
        }
}
void ImprimeMatInt(int mat[F][C]){

    int f,c;
    for( f = 0 ; f<F ; f++){
        for( c = 0 ; c<C ; c++){

            printf("%-4d",mat[f][c]);

        }
        printf("\n");
    }
}
