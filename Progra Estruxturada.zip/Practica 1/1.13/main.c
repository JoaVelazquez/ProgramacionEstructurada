#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define Fi 5
#define Ci 8
#define N 25
#define F 25
#define C 25

int main()
{
    int matdatos[Fi][Ci],opcion;
    char matequipos[F][C];
    char matcabecera[F][C];


    CargaMatIntDeArch(matdatos,"datos.txt");
    cargarMatTxtDeArch(matequipos,"equipos.txt");
    cargarMatTxtDeArch(matcabecera,"cabeceras.txt");
    imprimeCabecera(matcabecera);
    imprimeCuerpo(matequipos,matdatos);
    imprimeMenu();

    scanf("%d",&opcion);
    while( !(opcion>0 && opcion<10)){
        printf("\nViste el %d entre las opciones? Pone alguno que este capo: ",opcion);
        scanf("%d",&opcion);
    }
    if(opcion == 9){

        ordenarTexto();

    }else{
        ordenarCompleto(matequipos,matdatos,opcion);
        imprimeCabecera(matcabecera);
        imprimeCuerpo(matequipos,matdatos);
    }
    return 0;
}
void ordenarCompleto(char matxt[F][C], int matint[Fi][Ci], int opcion){

    opcion = opcion-1;
    int f,j;
    char aux[C];
    for( f=0 ; f<Fi-1 ; f++){
        for( j=f+1 ; j<Fi ; j++){
            if( (matint[f][opcion])>(matint[j][opcion])){
                intercambiarFilasInt(matint[f],matint[j],matxt[f],matxt[j]);
                strcpy(aux,matxt[f]);
                strcpy(matxt[f],matxt[j]);
                strcpy(matxt[j],aux);
            }
        }
    }

}
void intercambiarFilasInt(int A[Ci],int B[Ci],char a[F],char b[F]){

    int c,aux[Ci];
    for( c=0; c<Ci ;c++){
        aux[c] = A[c];
        A[c] = B[c];
        B[c] = aux[c];
    }


}
void imprimeMenu(){

    printf("Introduzca la opcion por la cual quiere ordenar (menor a mayor) :\n");
    printf("1.PTS\n");
    printf("2.PJ\n");
    printf("3.PG\n");
    printf("4.PE\n");
    printf("5.PP\n");
    printf("6.GF\n");
    printf("7.GC\n");
    printf("8.DIF\n");
    printf("9.NOMBRE\n");


}
int CargaMatIntDeArch(int mat[Fi][Ci],char nombre[]){

    int f;
    FILE* archivo;
    archivo = fopen(nombre,"r");
    if( archivo == NULL){
        printf("El archivo esta vacio.\n");
        return -1;
    }
    int n0,n1,n2,n3,n4,n5,n6,n7;
    for( f=0 ; (f<Fi) && (fscanf(archivo,"%d,%d,%d,%d,%d,%d,%d,%d",&n0,&n1,&n2,&n3,&n4,&n5,&n6,&n7) != EOF) ; f++){
   // printf("\n%d,%d,%d,%d,%d,%d,%d,%d\n",n0,n1,n2,n3,n4,n5,n6,n7);
        mat[f][0]=n0;
        mat[f][1]=n1;
        mat[f][2]=n2;
        mat[f][3]=n3;
        mat[f][4]=n4;
        mat[f][5]=n5;
        mat[f][6]=n6;
        mat[f][7]=n7;
        }
}

void cargarMatTxtDeArch(char mat[F][C], char nombre[]){

    char ch;
    int f,c;

    FILE* archivo;
    archivo = fopen(nombre,"r");
    ch = fgetc(archivo);

    if( archivo == NULL){
        printf("El archivo esta vacio.\n");
        return -1;
    }

    for( f = 0 ; (ch!=EOF) && (f<F-1) ; f++){
        for ( c = 0 ; (ch!=EOF) && (c<C-1) && (ch!='\n') ; c++){

            mat[f][c] = ch;
            ch = fgetc(archivo);
        }

        mat[f][c] = '\0';
        ch = fgetc(archivo);

    }
    mat[f][0] = '\0';
    fclose(archivo);
}

void imprimeCuerpo(char matxt[F][C], int matint[Fi][Ci]){

    int f;
    for( f=0 ; matxt[f][0]!='\0' && f<F ; f++ ){
            printf("%-15s",matxt[f]);
            imprimeFilaInt(matint[f]);
            printf("\n");
        }

}
void imprimeFilaInt(int mat[Ci]){

    int c ;
    for ( c=0 ; c<Ci ; c++){
        printf("%-6d",mat[c]);
    }


}
void imprimeCabecera(char mat[F][C]){

    int f,c;

    for( f = 0 ; mat[f][0]!='\0' && f<F ; f++){
            if(f==0){
                printf("%-15s",mat[f]);
            }else{
                printf("%-6s", mat[f]);
            }
        }
    printf("\n");
    printf("-----------------------------------------------------------");
    printf("\n");
}

void ordenarTexto(char mat[][N]){

    printf("\n-------------ORDENA-------------\n");
    int f,j;
    char aux[F];
    for( f=0 ; mat[f][0]!='\0' && f<F ; f++){
        for(j=0 ; mat[j][0]!='\0' && j<F ;  j++){
            if(strcmp(mat[f],mat[j])){

                strcpy(aux,mat[f]);
                strcpy(mat[f],mat[j]);
                strcpy(mat[j],aux);

            }
        }
    }

}
