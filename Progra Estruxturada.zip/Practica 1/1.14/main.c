#include <stdio.h>
#include <stdlib.h>
#define F 12
#define C 31

void CargarMatDatos(int mat[F][C], char nombre[]);
void ValMasCaluroso(int matProm[F]);
void ValMenosCaluroso(int matProm[F]);
void diasMedidos(int matProm[F]);

int main(){

    int matTemp[F][C],matDias[F],matProm[F];
    CargarMatDatos(matTemp,"temperaturas.txt");
    //imprimirMatInt(matTemp);
    CargarDiasInt(matDias,"diasMedidos.txt");
    valorMinimoAnual(matTemp,matDias);
    valorMaxAnual(matTemp,matDias);
    printf("\n-----------------");
    promedioMensual(matTemp,matDias,matProm);
    printf("\n-----------------");
    ValMasCaluroso(matProm);
    ValMenosCaluroso(matProm);
    printf("\n-----------------");
    diasMedidos(matProm);

    return 0;
}

void CargarDiasInt(int mat[F],char nombre[]){

    int f;
    int n0,n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11;

    FILE* arch;
    arch = fopen(nombre,"r");
    if( arch == NULL){
        printf("El archivo esta vacio o es inexistente.");
    }else{
        fscanf(arch,"%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d", &n0,&n1,&n2,&n3,&n4,&n5,&n6,&n7,&n8,&n9,&n10,&n11);
        mat[0] = n0;
        mat[1] = n1;
        mat[2] = n2;
        mat[3] = n3;
        mat[4] = n4;
        mat[5] = n5;
        mat[6] = n6;
        mat[7] = n7;
        mat[8] = n8;
        mat[9] = n9;
        mat[10] = n10;
        mat[11] = n11;
        }
    fclose(arch);
    }


void CargarMatDatos(int mat[F][C],char nombre[]){

    int f;
    int n0,n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,n16,n17,n18,n19,n20,n21,n22,n23,n24,n25,n26,n27,n28,n29,n30;

    FILE* arch;
    arch = fopen(nombre,"r");
    if( arch == NULL){
        printf("El archivo esta vacio o es inexistente.");
    }else{
        for( f=0 ; f<F && fscanf(arch,"%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d",&n0,&n1,&n2,&n3,&n4,&n5,&n6,&n7,&n8,&n9,&n10,&n11,&n12,&n13,&n14,&n15,&n16,&n17,&n18,&n19,&n20,&n21,&n22,&n23,&n24,&n25,&n26,&n27,&n28,&n29,&n30)!=EOF ; f++){

        mat[f][0] = n0;
        mat[f][1] = n1;
        mat[f][2] = n2;
        mat[f][3] = n3;
        mat[f][4] = n4;
        mat[f][5] = n5;
        mat[f][6] = n6;
        mat[f][7] = n7;
        mat[f][8] = n8;
        mat[f][9] = n9;
        mat[f][10] = n10;
        mat[f][11] = n11;
        mat[f][12] = n12;
        mat[f][13] = n13;
        mat[f][14] = n14;
        mat[f][15] = n15;
        mat[f][16] = n16;
        mat[f][17] = n17;
        mat[f][18] = n18;
        mat[f][19] = n19;
        mat[f][20] = n20;
        mat[f][21] = n21;
        mat[f][22] = n22;
        mat[f][23] = n23;
        mat[f][24] = n24;
        mat[f][25] = n25;
        mat[f][26] = n26;
        mat[f][27] = n27;
        mat[f][28] = n28;
        mat[f][29] = n29;
        mat[f][30] = n30;

        }
    }
    fclose(arch);
}

void imprimirMatInt(int mat[F][C]){

    int f,c;
    for( f=0 ; f<F ; f++){
        for( c=0 ; c<C ; c++){
            if( mat[f][c]!=-100){
            printf("%-3d",mat[f][c]);
            }
        }
        printf("\n");
    }
}
void valorMinimoAnual(int mat[F][C], int dias[F]){

    int f,c;
    int valMin = 100;
    for( f=0 ; f<F-1 ; f++){
        for( c=0 ; c<(dias[f])-1 ; c++){
            if( mat[f][c] < valMin){
                valMin = mat[f][c];
            }
        }
    }
    printf("\n-El valor minimo anual es: %d", valMin);
}
void valorMaxAnual(int mat[F][C], int dias[F]){

    int f,c;
    int valMax = -100;
    for( f=0 ; f<F-1 ; f++){
        for( c=0 ; c<(dias[f])-1 ; c++){
            if( mat[f][c] > valMax){
                valMax = mat[f][c];
            }
        }
    }
    printf("\n-El valor maximo anual es: %d", valMax);
}
void promedioMensual(int mat[F][C],int dias[F],int matProm[F]){

    int f,c;
    int prom = 0;
    for ( f=0 ; f<F ; f++){
        for( c=0 ; c<(dias[f])-1 ; c++){
            prom = prom+ mat[f][c];
        }
        printf("\n-El valor promedio mensual %d es de : %d",f+1,prom/(dias[f]-1) );
        matProm[f] = prom/(dias[f])-1;
        printf("\n%d\n",matProm[f]);
        prom = 0;
    }
}

void ValMasCaluroso(int matProm[F]){

    int f,mes;
    int valMax = -100;
    for( f=0 ; f<F ; f++){
        if( matProm[f]>valMax){
            valMax = matProm[f];
            mes = f+1;
        }
    }
    printf("\nEl mes mas caluroso es %d , y tiene una temperatura promedio de %d.",mes,valMax);
}
void ValMenosCaluroso(int matProm[F]){

    int f,mes;
    int valMin = 100;
    for( f=0 ; f<F ; f++){
        if( matProm[f]<valMin){
            valMin = matProm[f];
            mes = f+1;
        }
    }
    printf("\n--El mes mas caluroso es %d , y tiene una temperatura promedio de %d.",mes,valMin);
}

void diasMedidos(int matProm[F]){

    int f,tot=0;
    for( f=0 ; f<F ; f++){
            printf("\n%d\n",matProm[f]);
        tot = tot + matProm[f];
    }
    printf("\n-La cantidad total de dias medidos fue de %d dias.",tot);

}







