#include <stdio.h>
#include <stdlib.h>
void Piso(float num);
void Techo(float num);
void Redondeo(float num);
int main()
{
    printf("Ingrese un numero real: ");
    float num = 0;
    scanf("%f",&num);
    Piso(num);
    Techo(num);
    Redondeo(num);
    return 0;
}
void Piso(float num){

    int piso =num;
    printf("\nPiso: %d",piso);

}
void Techo(float num){

    int piso = num;

    if ( (num-piso) == 0  ){
        printf("\nTecho: %d",piso);
    }else{
    int techo = num+1;
    printf("\nTecho: %d",techo);
    }

}
void Redondeo(float num){

    int piso = num;

    if ( (num-piso)> 0.5  ){
        printf("\nRedondeo: %d",piso+1);
    }else{
        printf("\nRedondeo: %d",piso);
    }

}
