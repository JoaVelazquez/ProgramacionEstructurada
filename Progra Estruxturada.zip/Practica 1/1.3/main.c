#include <stdio.h>
#include <stdlib.h>
#define X 100

void CargarTxt(char txt[X]);
void IntercambiaLetra(char txt[X],int largo);
void ImprimirTxt(char txt[X],int largo);

int main()
{
    char txt[X];
    CargarTxt(txt);
}

void CargarTxt(char txt[X]){

    int i;
    char c;
    printf("Ingrese un texto ( Max 100 palabras): ");
    c = getche();

    for( i = 0; i<100 && c != '\r' ; i++){
        txt[i] = c;
        c = getche();
    }
    printf("\nLargo: %d\n",i);
    ImprimirTxt(txt,i);

}

void IntercambiaLetra(char txt[X],int largo){

    printf("\nIngrese letra a reemplazar: ");
    char c;
    c = getchar;
    printf("\nIngrese laletra que reemplazara la anterior: ");
    char s;
    s = getchar();

    int i;
    for( i = 0; i < largo ; i++){

        if((txt[i]) == c ){
            txt[i] = s;
        }
    }

}

void ImprimirTxt(char txt[X],int largo){

    int i;
    for(i =0  ; i<largo ; i++){
        printf("%c",txt[i]);
    }



}
