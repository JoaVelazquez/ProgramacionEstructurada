#include <stdio.h>
#include <stdlib.h>
#define X 100

int cargarArr(int Arr[X]);
void imprimirArr(int Arr[X]);
void invertirArr(int Arr[X],int arrInv[X],int largo);

int main()
{
    int Arr[X];
    int arrInv[X];
    int i = cargarArr(Arr);
    imprimirArr(Arr);
    invertirArr(Arr,arrInv, i);
    imprimirArr(arrInv);
    return 0;
}

int cargarArr(int Arr[X]){

    int i;
    int val = 1;
    printf("Ingrese los valores del arreglo y presione 0 para terminar: \n");
    scanf("%d,",&val);
    for ( i = 0 ;i<X && val!=0; i++){
        Arr[i] = val;
        scanf("%d,",&val);

    }
    Arr[i] = 0;
    printf("\nEl largo es: %d\n",i);
    printf("El arreglo es : (");
    return i;
}

void imprimirArr(int Arr[X]){

    int i;
    for ( i = 0 ; Arr[i]!=0 ; i++){
        printf("%d,",Arr[i]);
    }
    printf(")");

}

void invertirArr(int Arr[X],int arrInv[X], int largo){

    int i,d;

    for (i = largo-1 ,d = 0 ; i >=0 ; i-- , d++){
        arrInv[d] = Arr[i];
    }
    arrInv[d] = 0;
    printf("\nEl arreglo invertido es : (");


}
