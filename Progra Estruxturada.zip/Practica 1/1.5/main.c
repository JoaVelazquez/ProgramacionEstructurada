#include <stdio.h>
#include <stdlib.h>
#define x 100

void cargarArrPNR(int arr[x]);
int estaEnArr(int arr[x], int val,int largo);
int esPos(int val);
void imprimirArr(int arr[x]);


int main(){
    int arr[x];
    CargarArrPNR(arr);
    imprimirArr(arr);
    return 0;
}

void CargarArrPNR(int arr[x]){

    int i;
    int valor;
    printf("Ingrese los valores del arreglo ( enteros positivos y sin repetir ) y 0 para terminar : \n");
    scanf("%d",&valor);

    for(i = 0 ; i<x && valor!=0 ; i++){

        if( estaEnArr(arr,valor,i)==1 && esPos(valor)==1 ){

            arr[i] = valor;
            scanf("%d",&valor);
        }
        else{
            scanf("%d",&valor);
        }
    }
    arr[i] = 0;
    printf("\nEl arreglo es (");

}

int estaEnArr(int arr[x], int val, int largo){

    int i;
    for( i = 0 ; i<largo ; i++){
        if( arr[i]==val){
            printf("\nEl numero ya esta en el arreglo, ingrese otro: ");
            return 0;
        }
    }
    return 1;
}


int esPos(int val){

    if( val >= 0){
        return 1;
    }
    else{
            printf("\nEl valor es negativo, ingrese uno positivo: ");
        return 0;
    }
}


void imprimirArr(int arr[x]){

    int i;
    for ( i = 0 ; arr[i]!=0 ; i++){
        printf("%d  ",arr[i]);
    }
    printf(")");

}
