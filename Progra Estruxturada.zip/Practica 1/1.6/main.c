#include <stdio.h>
#include <stdlib.h>
#define X 100
void normalizar(char txt[X]);
void cargarTxt(char txt[X]);
void EsMayus(char txt[X]);
void imprimirTxt(char txt[X]);
void EsEspacio(char txt[X], int i);
void EsPunto( char txt[X], int i);

int main()
{
    char txt[X];
    cargarTxt(txt);
    printf("\nTexto crudo: ");
    imprimirTxt(txt);
    normalizar(txt);
    printf("\nTexto normalizado: ");
    imprimirTxt(txt);
    return 0;
}

void cargarTxt(char txt[X]){

    int i;
    char c;
    printf("Ingrese un texto:\n");
    c = getche();

    for(i = 0 ; c!= '\r' && i<X ; i++){

        txt[i] = c;
        c = getche();

    }
    txt[i] = '\0';

}
void normalizar(char txt[X]){

    int i;
    EsMayus(txt);

    for( i = 1 ; i<X && txt[i]!=0 ; i++ ){
        if( txt[i] == ' ' ){
            EsEspacio(txt,i);
        }

    }
    txt[i] = '\0';
    printf("\nEsta es la ultima letra:  %c",txt[i-1]);
    EsPunto(txt,i);

}
void EsEspacio(char txt[X], int i){

    if( txt[i+1] == ' '){//Si hay dos espacios seguidos...
        for( int f = i ; txt[f]!='\0' ; f++){

            txt[f] = txt[f+1];
        }
    }

}
void EsPunto( char txt[X], int i){

    if( txt[i-1] != '.' ){
        txt[i] = '.';
        txt[i+1] = '\0';
    }
}
void EsMayus(char txt[X]){

    if( !('A'>txt[0] && txt[0]>'Z') ){
        txt[0] = txt[0]-32;
    }

}
void imprimirTxt(char txt[X]){

    int i;
    printf("\n");
    for ( i = 0 ; txt[i]!= '\0' ; i++){

        printf("%c", txt[i]);
    }



}
