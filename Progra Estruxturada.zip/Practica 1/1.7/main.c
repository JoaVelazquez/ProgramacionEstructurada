#include <stdio.h>
#include <stdlib.h>
#define F 5
#define C 5
void cargarMat(int mat[F][C]);
void imprimirMat(int mat[F][C]);
void promMat(int mat[F][C]);

int main()
{
    int mat[F][C];
    printf("La matriz tiene %d filas y %d columnas.\n",F,C);
    cargarMat(mat);
    imprimirMat(mat);
    promMat(mat);
    return 0;
}

void cargarMat(int mat[F][C]){

    int f,c,val;

    for( f = 0 ; f<F ; f++){
        for( c = 0 ; c<C; c++){
            printf("\nIngrese el valor de [%d][%d]: ",f+1,c+1);
            scanf("%d",&val);
            mat[f][c] = val;
        }
    }
}

void imprimirMat(int mat[F][C]){

    int f,c;
    printf("La matriz es: \n");
    for( f = 0 ; f<F ; f++ ){
        for( c = 0 ; c<C ; c++){
            printf("[%d]",mat[f][c]);
        }
        printf("\n");
    }

}

void promMat(int mat[F][C]){

    int f,c;
    int valor = 0;
    for( f = 0 ; f<F ; f++ ){
        for( c = 0 ; c<C ; c++){
                valor = valor + mat[f][c];
        }
    }
    valor = valor/(F*C);
    printf("\nEl valor promedio de la matriz es de %d.",valor);



}
