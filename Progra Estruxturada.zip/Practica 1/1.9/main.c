#include <stdio.h>
#include <stdlib.h>
#define F 4
#define C 50

void Imprimir(char txt[F][C]);
void cargarMatTxt(char txt[F][C]);
void Ordenar(char txt[F][C]);
void strcpy(char A[],char B[]);

int main()
{
    char txt[F][C];
    cargarMatTxt(txt);
    Imprimir(txt);
    Ordenar(txt);
    printf("\n\nTexto ordenado : \n");
    Imprimir(txt);
    return 0;
}

void cargarMatTxt(char txt[F][C]){

    int f,c;
    char caracter;


    for( f = 0 ; f<F  ; f++){
        printf("\nIngrese el texto de la fila %d:  ",f+1);
        caracter = getche();
        for ( c = 0 ; c<C && caracter!='\r' ; c++){
            txt[f][c] = caracter;
            caracter = getche();
        }
        printf("\n");
        txt[f][c] = '\0';
    }
}

void Imprimir(char txt[F][C]){

    int f,c;

    for( f=0 ; f<F ; f++){
            printf("Fila %d: ",f+1);
        for( c=0 ; txt[f][c]!='\0' ; c++){
            printf("%c",txt[f][c]);
        }
        printf("\n");
    }

}
void Ordenar(char txt[F][C]){

    int f,j;
    char aux[C];
    for( f=0 ; f<F-1 ; f++){
        for( j=f+1 ; j<F ; j++){
            if( strcmp(txt[f],txt[j])){// si fila f>j devuelve true y entra, si no la funcion devuelve 0 y se saltea este paso.
                strcpy(aux,txt[f]);
                strcpy(txt[f],txt[j]);
                strcpy(txt[j],aux);
            }
        }
    }
}
void strcpy(char A[],char B[]){//Se pega en arr A el arr B ( destino / origen )

    int c;
    for( c=0 ; c<C  ; c++){

        A[c] = B[c];

    }
}
int strcmp(char A[], char B[]){

    int c=0;
    for( c=0 ; c<C && A[c]!='\0' && B[c]!='\0'; c++){
            //printf("\nCompara %c con %c\n",A[c],B[c]);
        if( A[c] > B[c] ){
            //printf(": 1");
            return 1;
        }
    }
    //printf(": 0");
    return 0;//falta pasar todo a mayus o minus para comparar.
}



