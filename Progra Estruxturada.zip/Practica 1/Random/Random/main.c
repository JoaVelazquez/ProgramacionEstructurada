#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("%d\n",(time(NULL)));
    printf("%d\n",rand());
    //(inf + rand()%(sup-inf)) ---> esto da un valor random entre SUP e INF
    return 0;
}
