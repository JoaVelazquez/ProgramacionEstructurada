#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define F 4
#define C 15

void CargaMatTxtDeArch(char mat[F][C],char nombre[]);
int IntercambiaViejoNuevo(char MatA[F][C], char MatB[F][C]);
void ImprimirMatTxt(char mat[F][C]);

int main()
{
    char mat[F][C] = {{'\0'}};
    char matB[F][C] = {{'\0'}};

    CargaMatTxtDeArch(mat,"nombres.txt");
    CargaMatTxtDeArch(matB,"correcciones.txt");
    printf("Archivo original : \n--------------");
    ImprimirMatTxt(mat);
    printf("\nArchivo Nuevo: \n--------------");
    ImprimirMatTxt(matB);
    printf("\nArchivo corregido: \n--------------");
    IntercambiaViejoNuevo(mat,matB);
    ImprimirMatTxt(mat);

    return 0;
}


void CargaMatTxtDeArch(char mat[F][C],char nombre[]){

    FILE* archivo;
    archivo = fopen(nombre,"r");
    int f,c;
    char ch;

    if( archivo == NULL){
        printf("\nERROR: El archivo esta vacio!\n");
    }else{

        ch = fgetc(archivo);
        for( f = 0 ; f<F && ch!=EOF ; f++ ){
            for( c = 0 ; c<C && ch!=EOF && ch!='\n' ; c++){

                mat[f][c] = ch;
                ch = fgetc(archivo);

            }
            ch = fgetc(archivo);
            mat[f][c] = '\0';
        }
        mat[f][c] = '\0';
    }
    fclose(archivo);
    printf("Archivo cargado con exito!\n");
}

int IntercambiaViejoNuevo(char matA[F][C], char matB[F][C]){

    int f;

    for( f = 0 ; f<F && matA[f][0]!='\0' ; f++){

        if( strcmp(matA[f],matB[0])==0){
            strcpy(matA[f],matB[1]);
            return 1;
        }
    }
}

void ImprimirMatTxt(char mat[F][C]){

    int f,c ;
    printf("\n");
    for( f = 0 ; mat[f][0]!='\0' ; f++ ){
        for( c = 0 ; mat[f][c]!='\0' ; c++){
            printf("%c",mat[f][c]);
        }
        printf("\n");
    }


}
