#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define F 4
#define C 15

void imprimir(char mat[F][C]);
int corrigeMat(char A[F][C],char B[F][C]);
void CargarMat(char mat[F][C],char nombre[]);

int main(){

    char mat[F][C] = {{0}};
    char matB[F][C] = {{0}};
    CargarMat(mat,"nombres.txt");
    printf("\nMatriz original:");
    printf("\n---------------------");
    imprimir(mat);
    CargarMat(matB,"correcciones.txt");
    printf("\nMatriz de correcciones:");
    printf("\n---------------------");
    imprimir(matB);

    if( corrigeMat(mat,matB) == 1){
        printf("\nMatriz ya corregida:");
        printf("\n---------------------");
        imprimir(mat);
    }else{

        printf("\nNo se pudo corregir la matriz.");
    }


    return 0;
}

void CargarMat(char mat[F][C],char nombre[]){

    FILE* arch;
    arch = fopen(nombre,"r");
    int f,c;
    char ch;
    if( arch == NULL){
        printf("El archivo esta vacio.");
    }
    else{
        ch = fgetc(arch);
        for( f=0 ; f<F && ch!=EOF ; f++){
            for( c=0 ; c<C && ch!=EOF && ch!='\n' ; c++){

                mat[f][c]=ch;
                ch = fgetc(arch);
            }
            ch = fgetc(arch);
            mat[f][c]='\0';
        }
        mat[f][0]='\0';
    }
    fclose(arch);
    printf("La matriz se cargo con exito!\n");
}

void imprimir(char mat[F][C]){

    int f,c;
    printf("\n");
    for( f=0 ; mat[f][0]!='\0' ; f++){
        for ( c=0 ; mat[f][c]!='\0' ; c++){

            printf("%c",mat[f][c]);
        }
        printf("\n");
    }
}
int corrigeMat(char A[F][C],char B[F][C]){

    int f;
    for( f=0; A[f]!='\0' ; f++){
        if((strcmp(A[f],B[0]))==0){
            strcpy(A[f],B[1]);
            printf("\nMatriz corregida!");
            return 1;
        }
    }
    return 0;
}
