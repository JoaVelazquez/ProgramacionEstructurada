#include <stdio.h>
#include <stdlib.h>
#include <math.h>

struct s_coord{

    float x;
    float y;

};
typedef struct s_coord t_coord;
float DistAOO( t_coord punto );
t_coord IngresaCoord(t_coord a);

int main()
{
    t_coord a,b;
    printf("Se ingresan las coordenadas A.\n");
    a = IngresaCoord(a);

    printf("Se ingresan las coordenadas B.\n");
    b = IngresaCoord(b);

    ComparaDist(a,b);

    return 0;
}
void ComparaDist( t_coord a, t_coord b){


    float distA = DistAOO(a);
    printf("La distancia al origen de la coordinada A es: %.2f\n",distA);


    float distB = DistAOO(b);
    printf("La distancia al origen de la coordinada B es: %.2f\n",distB);

    if( distA<distB){
        printf("La distancia de A ( %.2f )es menor a la distancia de B ( %.2f ).",distA,distB);
    }
    else{
        printf("La distancia de B ( %.2f )es menor a la distancia de A ( %.2f ).",distB,distA);
    }

}
t_coord IngresaCoord(t_coord a){

    printf("Por favor ingrese el valor x : ");
    scanf("%f",&(a.x));
    printf("Por favor ingrese el valor y : ");
    scanf("%f",&(a.y));
    printf("\n");
    return a;


}
float DistAOO( t_coord punto ){
    return sqrt(pow(punto.x,2) + pow(punto.y,2));

}


