#include <stdio.h>
#include <stdlib.h>

int main()
{
    unsigned int val = 31;
    ImprimeCharEnBinario(val);
    CuentaUnos(val);

    return 0;
}

void CuentaUnos(unsigned int val){

    unsigned int mask = 1;
    int contador=0,i, tam = 8;

    for ( i = 1 ; i<=(tam) ; i++){

        if( (mask&(val>>(tam-i))) == 1 ){
            contador++;
        }

    }
    printf("\nLa cantidad de 1 es de %d .",contador);

}
void ImprimeCharEnBinario( unsigned int val){


    unsigned int mask = 1;
    int i,tam=8;

    for( i = 1 ; i<=tam ; i++){

        printf("%d",((val>>(tam-i))&mask));
    }

}
