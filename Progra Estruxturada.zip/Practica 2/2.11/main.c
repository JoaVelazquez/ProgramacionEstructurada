#include <stdio.h>
#include <stdlib.h>

int main()
{
    unsigned char a='a',b='b',c='c',d='d';
    unsigned int var = 0;
    GuardaCharsEnInt(var,a,b,c,d);

    return 0;
}

void GuardaCharsEnInt(unsigned int var, char a, unsigned char b, unsigned char c, unsigned char d){

    ImprimeCharEnBinario(var);
    var = var | a;
    ImprimeCharEnBinario(var);
    var = var<<8;
    var = var | b;
    ImprimeCharEnBinario(var);
    var = var<<8;
    var = var | c;
    ImprimeCharEnBinario(var);
    var = var<<8;
    var = var | d;
    ImprimeCharEnBinario(var);


}
void ImprimeCharEnBinario( unsigned int var){

    printf("\n");
    unsigned int mask = 1;
    int i,tam=32;

    for( i = 1 ; i<=tam ; i++){

        printf("%-2d",((var>>(tam-i))&mask));
        if( (i%8) == 0){
            printf("|");
        }
    }
    printf("\n\n");
}
