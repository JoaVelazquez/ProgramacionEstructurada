#include <stdio.h>
#include <stdlib.h>

int main()
{
    char var = '';
    ImprimeCharEnBinario(var);
    printf("\n");
    CambiaLetra(var);
    return 0;
}

void CambiaLetra(char var){

    unsigned int mask = 1;
    mask = mask << 5;
    var = var ^ mask;
    ImprimeCharEnBinario(var);

}

void ImprimeCharEnBinario( char var){

    printf("\n");
    unsigned int mask = 1;
    int i,tam=8;
    printf("|");
    for( i = 1 ; i<=tam ; i++){

        printf("%-2d",((var>>(tam-i))&mask));
        if( (i%8) == 0){
            printf("|");
        }
    }
    printf(" '%c'",var);
    printf("\n\n");
}
