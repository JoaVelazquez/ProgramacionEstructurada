#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define F 10

struct s_coord{

    float x;
    float y;

};
typedef struct s_coord t_coord;
void CargarArch(t_coord arr[10] , char nombre[]);
float DistMinimaPuntosDados( t_coord a, t_coord b);
float CalculaNorma( t_coord coord);
void ImprimeCoord( t_coord arr[10]);
float DevuelveDistMinEnArr(t_coord arr[10]);
float DevuelveDistMinConsec(t_coord arr[10]);

int main()
{
    t_coord arr[10];
    int a,b;
    CargarArch(arr,"puntos.txt");
    ImprimeCoord(arr);
    printf("-Ingrese el numero de la coordinada A: ");
    scanf("%d",&a);

    printf("-Ingrese el numero de la coordinada B: ");
    scanf("%d",&b);
    printf("-La distancia entre el punto A  y B es de: %.1f.",DistMinimaPuntosDados(arr[a-1],arr[b-1]));

    printf("\n\n-----------------------------------------------------\n");
    //----------------------------------
    float dis = DevuelveDistMinEnArr(arr);
    printf("La distancia minima entre dos puntos de todo el arreglo es de: %.2f",dis);

    printf("\n\n-----------------------------------------------------\n");
    float dis_con = DevuelveDistMinConsec(arr);

    printf("La distancia minima entre dos puntos consecutivos es de: %.2f",dis_con);

    return 0;
}
float DevuelveDistMinConsec(t_coord arr[10]){

    int f;
    float dis_min,dis;
    dis_min = CalculaNorma(arr[0]);
    for( f=0 ; f<F-1 ; f++){
        dis = DistMinimaPuntosDados(arr[f],arr[f+1]);
        printf("\nDist : %.1f\n",dis);
        if( dis < dis_min){
            dis_min = dis;
        }
    }
    return dis_min;


}
float DevuelveDistMinEnArr(t_coord arr[10]){

    int f,j;
    float dis_min,dis;
    dis_min = CalculaNorma(arr[0]);
    for( f=0 ; f<F-1 ; f++){
        for( j=f+1  ; j<F ; j++){
                dis = DistMinimaPuntosDados(arr[f],arr[j]);
                printf("\nDist : %.1f\n",dis);
            if( dis < dis_min ){
                dis_min = dis;
            }
        }
    }
    return dis_min;

}




void CargarArch(t_coord arr[10] , char nombre[]){

    int f;
    FILE* arch;
    arch = fopen(nombre, "r");

    if( arch==NULL ){
        printf("El archivo esta vacio!");
    }
    else{
        float x,y;

        for( f=0 ; f<F & fscanf( arch,"%f,%f",&x,&y)!=EOF ; f++ ){

            (arr[f]).x = x;
            (arr[f]).y = y;

        }
    }
}
float DistMinimaPuntosDados( t_coord a, t_coord b){

    t_coord dif;
    printf("a = (%.1f ; %.1f)  b = (%.1f ; %.1f) \n",a.x,a.y,b.x,b.y);
    dif.x = (b.x) - (a.x);
    dif.y = (b.y) - (a.y);

    return CalculaNorma(dif);



}

float CalculaNorma( t_coord coord){

    return sqrt( pow( coord.x,2 ) + pow( coord.y,2 ) );

}

void ImprimeCoord( t_coord arr[10]){
    printf("     X    Y\n");
    for( int f=0 ; f<10 ; f++){
        printf("%d)( %.1f , %.1f )\n",f+1,arr[f].x,arr[f].y);
    }

}


