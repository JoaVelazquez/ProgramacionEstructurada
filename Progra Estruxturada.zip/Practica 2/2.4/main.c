#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#define T 50
#define N 4
struct s_persona{

    int dni;
    char nombre[T];
    char pais[T];

};
typedef struct s_persona t_persona;

void CargaStr(char str[T]);
void CargaArr(t_persona arr[N]);
void CargaArrEnArch(t_persona arr[N],char nombre[]);

int main(){

    t_persona arr[N] = {0};
    CargaArr(arr);
    CargaArrEnArch(arr,"ejercicio.csv");
    return 0;
}

void CargaArr(t_persona arr[N]){

    int f = 0 ,dni ;
    char pais[T],nombre[T];
    printf("Ingrese el valor del documento ( cuando el dni sea 0 se terminara la carga): ");
    scanf("%d",&dni);

    for( f=0 ; f<N-1 && dni != 0  ; f++){

        arr[f].dni = dni;
        printf("\nIngrese nombre: ");
        CargaStr(arr[f].nombre);

        printf("\nIngrese pais: ");
        CargaStr(arr[f].pais);

        printf("\nIngrese el dni de una nueva persona: ");
        scanf("%d",&dni);

    }
    arr[f].dni = 0;

}
void CargaArrEnArch(t_persona arr[N],char nombre[]){

    int f;
    FILE* arch;
    arch = fopen(nombre , "a");

    for ( f=0 ; f<N && arr[f].dni!=0 ; f++ ){

        fprintf(arch,"%d,%s,%s\n",arr[f].dni,arr[f].nombre,arr[f].pais);

    }

}
void CargaStr(char str[T]){

    char c;
    int i;
    c = getche();

    for( i = 0 ; i<T && c!='\r' ; i++){

        str[i] = c;
        c = getche();
    }

}
