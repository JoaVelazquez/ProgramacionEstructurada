#include <stdio.h>
#include <stdlib.h>


void ImprimeCharEnBinario( char c);

int main()
{
    char c = 'a';
    ImprimeCharEnBinario(c);
    return 0;
}

void ImprimeCharEnBinario( char c){


    unsigned int mask = 1;
    int i,tam=8;

    for( i = 1 ; i<=tam ; i++){

        printf("%d",((c>>(tam-i))&mask));
    }

}
