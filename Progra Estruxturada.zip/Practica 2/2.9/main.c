#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void ImprimeBinario(char c);
void ArmaMask(char c,int j);

int main()
{
    char c = 255;
    int cant;
    printf("Ingrese la cantidad de posiciones que desea shiftear hacia la derecha: ");
    scanf("%d",&cant);

    ImprimeBinario(c);
    ArmaMask(c,cant);
    return 0;
}

void ArmaMask(char c,int j){

    int i,mask = 0 ;
    int tam = 8;
    c = c>>j;
    for( i=0 ; i<=(tam-1)-j ; i++){

        mask = mask+pow(2,i);

    }
    printf("\n");
    char valor = ("%d",((c>>j)&mask));

    ImprimeBinario(valor);

}
void ImprimeBinario(char c){
    printf("\n");
    unsigned int mask = 1;
    int i,tam=8;

    for( i = 1 ; i<=tam ; i++){

        printf("%-2d",((c>>(tam-i))&mask));
    }

}
