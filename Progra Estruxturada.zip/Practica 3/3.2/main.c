#include <stdio.h>
#include <stdlib.h>

int retornaPosDeMemoria( int arr[], int pos );

int main()
{
    int arr[5] = {30,3,2,4,5};
    printf("Indique una posicion del arreglo: ");
    int pos;
    scanf("%d",&pos);
    printf("\nLa direccion de memoria de esa posicion es: %d",retornaPosDeMemoria(arr,pos));
    return 0;
}
int retornaPosDeMemoria( int arr[], int pos ){

    return &arr[pos];

}
