#include <stdio.h>
#include <stdlib.h>
typedef struct{

    int a,b,c;

}t_tres;

void imprimeS( t_tres var);

int main()
{
    t_tres x,y,z;
    x.a = 5;
    x.b = 7;
    x.c = 2;

    y.a = 1;
    y.b = 2;
    y.c = 3;

    z.a = 4;
    z.b = 3;
    z.c = 5;

    printf("SIN ORDENAR\n\n");
    printf("X : ");
    imprimeS(x);
    printf("Y : ");
    imprimeS(y);
    printf("Z : ");
    imprimeS(z);

    printf("ORDENADAS\n\n");
    ordenaT(&x);
    ordenaT(&y);
    ordenaT(&z);
    printf("X : ");
    imprimeS(x);
    printf("Y : ");
    imprimeS(y);
    printf("Z : ");
    imprimeS(z);




    return 0;
}

void ordenaT( t_tres *var ){

    int aux;

    if( (*var).a > (*var).b ){

        aux = (*var).a;
        (*var).a = (*var).b;
        (*var).b = aux;

    }
    if( (*var).a > (*var).c ){

        aux = (*var).a;
        (*var).a = (*var).c;
        (*var).c = aux;

    }
    if( (*var).b > (*var).c ){

        aux = (*var).b;
        (*var).b = (*var).c;
        (*var).c = aux;

    }


}
void imprimeS( t_tres var){

    printf("\n%-3d",var.a);
    printf("%-3d",var.b);
    printf("%-3d\n\n",var.c);

}
