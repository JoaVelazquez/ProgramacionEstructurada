#include <stdio.h>
#include <stdlib.h>

char * cargarStrDin();

int main()
{
    printf("Ingrese su texto y finalice con enter: \n");
    printf("\n%s",cargarStrDin());
    return 0;
}

char * cargarStrDin(){

    char * arr = (char *) malloc( sizeof(char));
    char c;
    c = getche();
    int i=0;

    while ( c != '\r'){

        *(arr + i) = c;
        i++;
        arr = realloc(arr, (i+1)*sizeof(char));
        c = getche();

    }
    *(arr+i)= '\0';
    return arr;


}
