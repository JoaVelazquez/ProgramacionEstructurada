#include <stdio.h>
#include <stdlib.h>

void cargarStrDin(char ** arr);
void escribirArch( const char * nomArch, char* cadena);
void imprimirArch(char * nomArch);
int main()
{
    char * arr = NULL;
    printf("Ingrese su texto y finalice con enter: \n");
    cargarStrDin(&arr);
    printf("\n%s",arr);
    escribirArch("frase.txt",arr);
    imprimirArch("frase.txt");
    return 0;
}

void  cargarStrDin(char ** arr){

    *arr = (char *) malloc( sizeof(char));
    char c;
    c = getche();
    int i=0;

    while ( c != '\r'){

        *(*arr + i) = c;
        i++;
        *arr = realloc(*arr, (i+1)*sizeof(char));
        c = getche();

    }
    *(*arr+i)= '\0';

}

void escribirArch( const char * nomArch, char* cadena){

    FILE* arch;
    arch = fopen( nomArch,"w");
    int f;

    for ( f=0 ; *(cadena+f)!='\0' ; f++){

            fputc(cadena+f,arch);

    }
    fclose(arch);
}
void imprimirArch(char * nomArch){

    FILE * arch;
    arch = fopen(nomArch,"r");
    printf("\n");
    int f;
    char c;
    c = fgetc(arch);
    for ( f = 0 ; c!=EOF ; f++){

        printf("%c",c);
        c = fgetc(arch);

    }
    fclose(arch);


}

