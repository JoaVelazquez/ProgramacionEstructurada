#include <stdio.h>
#include <stdlib.h>

void Cargar( int ** arr );
void Imprime( int ** arr );
void DifSimetrica( int * a, int * b, int ** arr );
void UnionDeArr( int * a, int * b, int ** arr );
void InterseccionDeArr( int * a, int * b, int ** arr );
int EstaEnLista( int * arr, int num);

int main(){

    int * arrA = NULL, arrB = NULL;
    printf("CARGA A: \n");
    Cargar(&arrA);
    printf("ARR A:");
    Imprime(&arrA);

    printf("\nCARGA B: \n");
    Cargar(&arrB);
    printf("ARR B:");
    Imprime(&arrB);

    int * DifSim = NULL;
    DifSimetrica(arrA,arrB,&DifSim);
    printf("\nDIF SIMETRICA: \n");
    Imprime(&DifSim);

    int * Union = NULL;
    UnionDeArr(arrA,arrB,&Union);
    printf("\nUNION: \n");
    Imprime(&Union);

    int * Inter = NULL;
    InterseccionDeArr(arrA,arrB,&Inter);
    printf("\nINTERSECCION:\n");
    Imprime(&Inter);

    return 0;
}
void InterseccionDeArr( int * a, int * b , int ** arr){

    int i, j = 0 ;
    *arr = malloc ( sizeof( int ));

    for ( i=0 ; *(a+i)!=0 ; i++){
        *((*arr)+j) = *(a+i);
        j++;
        *arr = realloc ( *arr, (j+1)*sizeof(int));

    }
    for ( i=0 ; *(b+i)!=0 ; i++){
        if ( EstaEnLista(*arr, *(b+i)) == 0){
           *((*arr)+j) = *(b+i);
           j++;
           *arr = realloc ( *arr, (j+1)*sizeof(int));
        }
    }
    *((*arr)+j) = 0;



}

void UnionDeArr( int * a, int * b, int ** arr ){

    int i, j = 0 ;
    *arr = malloc ( sizeof(int));

    for ( i = 0 ; *(a+i)!= 0 ; i++ ){
        if ( EstaEnLista(b,*(a+i))){
            *((*arr)+j) = *(a+i);
            j++;
            *arr = realloc(*arr, (j+1)*sizeof(int));
        }
    }
    *((*arr)+j) = 0;
}

void DifSimetrica( int * a, int * b, int ** arr ){

    int i , j=0 ;
    *arr = malloc( sizeof(int));

    for ( i=0 ; *(a+i)!=0 ; i++ ){

        if( EstaEnLista( b , *(a+i)) == 0 ){

            *((*arr)+j) = *(a+i);
            j++;
            *arr = realloc( *arr, (j+1)*sizeof(int));


        }
    }
    for ( i=0 ; *(b+i)!=0 ; i++ ){

        if( EstaEnLista( a , *(b+i)) == 0 ){

            *((*arr)+j) = *(b+i);
            j++;
            *arr = realloc( *arr, (j+1)*sizeof(int));


        }
    }
    *((*arr)+j) = 0;

}
int EstaEnLista(int * arr, int num ){

    for ( int i = 0 ; *(arr+i)!= 0 ; i++ ){
        if ( *(arr+i) == num ){
            return 1;
        }
    }
    return 0;


}
void Cargar( int ** arr ){

    int num, i=0 ;
    *arr = malloc(sizeof(int));

    printf("Ingrese los valores del arreglo y 0 para terminar:\n");
    scanf( "%d",&num );

    while( num != 0){

        *((*arr)+i) = num;
        i++;
        *arr = realloc( *arr , (i+1)*sizeof(int));
        scanf("%d",&num);

    }

    *((*arr)+i) = 0;

}
void Imprime( int ** arr ){

    int i;
    printf("\n[ ");
    for( i = 0 ; *((*arr)+i) != 0 ; i++ ){


        printf("%d ", *((*arr)+i));

    }
    printf("]\n");

}



