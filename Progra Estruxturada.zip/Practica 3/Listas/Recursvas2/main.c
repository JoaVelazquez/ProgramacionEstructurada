#include <stdio.h>
#include <stdlib.h>

void Cargar( char ** arr );
void Imprime( char ** arr);
int esVocal( char c );
int * MaxNumArr( int * arr );
int main()
{/*
    char * arr = NULL;
    Cargar(&arr);
    Imprime(&arr);
    char pal[5]= "hola";
    printf("\nCantidad de vocales en el arr: %d",CuentaVocales(pal));
*/
    int * arrA = NULL;
    CargarInt(&arrA);
    printf("\nEl max valor del arr es %d",MaxNumArr(arrA));

    return 0;
}
int * MaxNumArr( int * arr ){

    int max = *arr;
    int maxsig;
    if ( *arr!= 0 && *(arr+1)!=0 ){
        maxsig = MaxNumArr(*(arr+1));
        if  ( maxsig > max){
            max = maxsig;
        }
    }
    return max;

}
void CargarInt( int ** arr ){

    *arr = malloc( sizeof(int));
    int i=0;
    int num;
    printf("\nIngrese los valores del arreglo y finalice con '0': \n");
    scanf("%d",&num);

    while(  num!=0 ){

        *((*arr)+i) = num;
        i++;
        *arr = realloc( *arr, (i+1)*sizeof(int) );
        scanf("%d",&num);

    }
    *((*arr)+i) = 0;

}
int CuentaVocales( char * arr ){

    if( (*arr) != '\0'){
        if ( esVocal((*arr)) ){
            return 1+CuentaVocales(arr+1);
        }
        else{
            return CuentaVocales(arr+1);
        }
    }else{
        return 0;
    }

}
int esVocal( char c ){

    char vocales[10] = {'a','e','i','o','u','A','E','I','O','U'};
    for ( int i = 0 ; i<10 ; i++){
        if( c==vocales[i]){
            return 1;
        }
    }
    return 0;
}
void Cargar( char ** arr ){

    char c;
    int i;
    *arr = malloc( sizeof(int));
    printf("Ingrese su texto ( enter para finalizar) :\n");
    c = getche();

    for ( i=0 ; c!='\r' ; i++){
        *((*arr)+i) = c;
        *arr = realloc( *arr, (i+1)*sizeof(int));
        c = getche();
    }
    *((*arr)+i) = '\0';

}
void Imprime( char ** arr){
    printf("\n");
    for ( int i = 0 ; *((*arr)+i)!='\0' ; i++){
        printf("%c",*((*arr)+i));
    }
}
