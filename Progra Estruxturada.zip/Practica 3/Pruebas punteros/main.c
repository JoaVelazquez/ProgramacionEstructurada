#include <stdio.h>
#include <stdlib.h>

int main()
{
    int var = 4;
    //fun(var);
    printf(" Se crea variable int \n\n int var = 4;\n\n");
    printf(" var  : %d\n",var);
    printf(" &var : %d\n",&var);
    printf("\n===========\n\n");

    printf(" Se crean variables int puntero\n\n int* p,c;\n c = 5;\n p = &c;\n\n");
    int* p,c;
    c = 5;
    p = &c;
    printf(" c  : %d\n",c);
    printf(" &c : %d\n",&c);
    printf(" *c : ERROR ( le esta pidiendo el contenido de NULL ) \n");
    printf(" p  : %d\n",p);
    printf(" &p : %d\n",&p);
    printf(" *p : %d\n",*p);
    printf("\n\n==========\n");
    imprimeStr("prueba");
    return 0;
}
void fun( int * p){

    printf("%d\n",*p);

}
void imprimeStr(char * str){

    printf("%s",str);
}
