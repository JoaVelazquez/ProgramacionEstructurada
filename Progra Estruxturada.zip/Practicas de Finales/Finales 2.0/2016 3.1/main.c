#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct sEmpleado{

    int codVendedor;
    char *nombre[30];
    int objetivoTarjetasAnual;
    double sueldoAnual;

};
typedef struct sEmpleado tEmpleado;

struct sNodoBin{

    tEmpleado empleado;
    struct sNodoBin * nodoIzq;
    struct sNodoBin * nodoDer;

};
typedef struct sNodoBin * tNodoBin;

int cargarArbolVendedores ( tNodoBin* arbol, FILE* fVende );
void cargarVendedorAlArbol( tEmpleado, tNodoBin*);
void enOrden(tNodoBin arbol);


int main()
{
    tNodoBin arbol = NULL;
    FILE* arch;
    arch = fopen( "vendedores.txt","r");
    cargarArbolVendedores(&arbol, arch)l
    enOrden(arbol);
    return 0;
}
int cargarArbolVendedores ( tNodoBin* arbool, FILE* fVende ){

    tEmpleado aux;
    char arr[30];
    char c;
    int i;

    if ( fVende!=NULL ){

        while ( fscanf( fVende, "%d,",&(aux.codVendedor)!=EOF )){
            i=0;
            c = fgetc(fVende);

            while( c!=','){
                arr[i] =  c;
                i++;
                fgetc(fVende);
            }
            strcpy(aux.nombre,arr);

            fscanf(fVende, "%d,",&(aux.objetivoTarjetasAnual));
            fscanf(fVende, "%d,",&(aux.sueldoAnual));

        }
    }

}

 void cargarVendedorAlArbol( tNodoBin* arbol, tEmpleado aux){

    if( *arbol == NULL ){
        *arbol = malloc( sizeof(tNodoBin));
        (*arbol)->empleado = aux;
        (*arbol)->nodoDer = NULL;
        (*arbol)->nodoIzq = NULL;
    }
    else{
        if(aux.codVendedor < ((*arbol)->empleado).codVendedor ){
            cargarVendedorAlArbol(&((*arbol)->nodoIzq),aux);
        }
        else{
            cargarVendedorAlArbol( &((*arbol)->nodoDer),aux);
        }
    }
}

void enOrden(tNodoBin arbol){

    if( arbol!=NULL){

        enOrden(arbol->nodoIzq);
        (printf("%d\n %s",arbol->empleado.codVendedor, arbol->empleado.nombre);
        enOrden(arbol->nodoDer);

    }
}

