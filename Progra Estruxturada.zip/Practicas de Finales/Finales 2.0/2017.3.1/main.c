/* 2017 B  --------------------  2017 B ---------------------- 2017 B */
#include <stdio.h>
#include <stdlib.h>

struct sAlumno{

    int registro;
    char * nombre;
    char * apellido;

};typedef struct sAlumno tAlumno;

struct sNodoBin{

    tAlumno alumno;
    struct sNodoBin *izq;
    struct sNodoBin * der;
};typedef struct sNodoBin * tNodoBin;

void cargaArrDeArch( char * nomArch, tAlumno ** comision);
void unificar ( char * arch1, char * arch2 );
void armaComisionFinal( tAlumno * A, tAlumno * B, tAlumno ** T);
void AgregaComisionFinalArbol(tNodoBin * arbol, tAlumno alumno);

int main()
{
    return 0;
}
void unificar ( char * arch1, char * arch2 ){

    tNodoBin arbol = NULL;
    tAlumno * com_A;
    tAlumno * com_B;
    tAlumno * com_Tot;
    int i=0;
    FILE * arch = fopen("comisionFinal.csv","w");

    cargaArrDeArch(arch1, &com_A);
    cargaArrDeArch(arch2, &com_B);

    armaComisionFinal( com_A,com_B,&com_Tot);

    while ( com_Tot[i]!=0){
        AgregaComisionFinalArbol(&arbol, com_Tot[i]);
        i++;
        }

}

void AgregaComisionFinalArbol(tNodoBin * arbol, tAlumno estudiante){

    if( *arbol == NULL){
        (*arbol) = malloc(sizeof(struct sNodoBin));
        (*arbol)->alumno = estudiante;
        (*arbol)->der = NULL;
        (*arbol)->izq = NULL;
    }
    else{
        if ( estudiante.registro < ((*arbol)->alumno).registro){
            AgregaComisionFinalArbol(&((*arbol)->izq),estudiante);

        }
        else if( estudiante.registro > ((*arbol)->alumno).registro){
            AgregaComisionFinalArbol(&((*arbol)->der),estudiante);
        }
    }

}
void armaComisionFinal( tAlumno * A, tAlumno * B, tAlumno ** T){

    *T = malloc( sizeof(tAlumno));
    int i = 0;
    int cont = 0;

    tAlumno finArr;
    finArr.apellido = NULL;
    finArr.nombre = NULL;
    finArr.registro = 0;
    while( A[i].registro!=0 ){
        *(*T + cont) = A[i];
        cont++;
        i++;
        *T = realloc(*T, sizeof(tAlumno)*(i+1));
    }
    i=0;
    while( B[i].registro!=0){
        *(*T + cont) = B[i];
        cont++;
        i++;
        *T = realloc( *T , sizeof(tAlumno)*(cont+1));
    }
    *(*T + cont) = finArr;

}
void cargaArrDeArch( char * nomArch, tAlumno ** comision){

    tAlumno aux;
    FILE * arch = fopen(nomArch,"r");
    char c;
    int cont = 0;
    int i = 0;

    tAlumno finArr;
    finArr.apellido = NULL;
    finArr.nombre = NULL;
    finArr.registro = 0;

    if( arch!=NULL ){

        *comision = malloc( sizeof(tAlumno));
        c = fgetc(arch);
        aux.nombre = malloc(sizeof(char));
        while( fscanf(arch,"%d,",&(aux.registro))!=EOF ){

             i=0;
             aux.nombre = malloc(sizeof(char));
             c = fgetc(arch);

             while ( c!=',' ){

                *(aux.nombre+i) = c;
                i++;
                aux.nombre = realloc(aux.nombre, sizeof(char)*(i+1));
                c = fgetc(arch);
            }
            *(aux.nombre)+i = '\0';
            aux.apellido = malloc(sizeof(char));
            i=0;
            c = fgetc(arch);
            while( c!='\n' ){
                *(aux.apellido+i) = c;
                i++;
                aux.apellido = realloc(aux.apellido, sizeof(char)*(i+1));
                c = fgetc(arch);
            }
            *(aux.apellido+i)= '\0';
            *(*comision + cont) = aux;
            cont++;
            *comision = realloc( *comision, sizeof(tAlumno)*(cont+1));
        }
        *(*comision + cont) = finArr;

    }

}






