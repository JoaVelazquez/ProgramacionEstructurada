#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct s_alu{
    char* apellido;
    t_nota lstNota;
    struct s_alu* sig;
};
typedef struct s_alu* t_alu;

struct s_nota{
    int valor;
    struct s_nota* sig;
};
typedef struct s_nota* t_nota;

struct arr{
    char* apellido;
    int promedio;
};
typedef struct arr t_arreglo;

struct s_arr{

    char* apellido;
    int promedio;

};


void agregarAlumno( t_alu *, char * );
void agregarNota( t_nota * DirNota, int nota);
void imprimirNotas( t_arreglo ** alumnos );
int obtenerPromedio( t_nota listaNotas);
int obtenerCant( t_nota listaNotas );


int main()
{

    return 0;
}
void Listado( t_arreglo listAlu ){

    printf("ALUMNO      PROMEDIO\n-----------------\n");

    for ( int i = 0 ; listAlu->apellido!=NULL ; i++){
        printf("%10s%10d\n",listAlu[i].apellido,listAlu[i]promedio);
    }

}
void armaArrAlumnos( t_arreglo ** alumnos, t_alu listaAlumnos){

    int i=0;
    *alumnos = malloc(sizeof(t_arreglo));
    t_arreglo aux;
    t_arreglo finArr;
    finArr.apellido = NULL;
    finArr.promedio = 0;

    while( listaAlumnos!=NULL ){

        aux.apellido = listaAlumnos->apellido;
        aux.promedio = obtenerPromedio(listaAlumnos->lstNota);
        *(*alumnos+i) = aux;
        i++;
        *alumnos = realloc( *alumnos, sizeof(t_arreglo)*(i+1));
        listaAlumnos = listaAlumnos->sig;

    }

}
int obtenerPromedio( t_nota listaNotas){

    int suma;
    int cant;
    int prom = 0;
    sum = obtenerSuma( listaNotas );
    cant = obtenerCant( listaNotas );
    if ( cant != 0 ){
        prom = suma/cant;
    }
    return prom;

}
int obtenerCant( t_nota listaNotas ){

    if( listaNotas!=NULL){
        return 1 + obtenerCant( listaNotas->sig);
    }
    else{
        return 0;
    }
}
int obtenerSuma( t_nota listaNotas ){

    if( listaNotas!=NULL){
        return listaNotas->valor + obtenerSuma(listaNotas->sig);
    }
    else{
        return ;
    }

}
void agregarAlumno( t_alu* DirAlumno, char * apellido){

    if ( DirAlumno == NULL){

        *(DirAlumno) = malloc( sizeof(struct s_alu));
        *(DirAlumno)->apellido = apellido;
        *(DirAlumno)->lstnota = NULL;
        *(DirAlumno)->sig = NULL;

    }
    else{
        agregarAlumno(&((*DirAlumno)->sig),apellido);
    }
}
void agregarNota( t_alu * DirNota, int nota){

    if ( DirNota == NULL){
        *(DirNota) = malloc(sizeof(struct s_nota));
        *(DirNota)->valor = nota;
        *(DirNota)->sig = NULL;
    }
    else{
        agregarNota(&((*DirNota)->sig), nota);
    }

}
