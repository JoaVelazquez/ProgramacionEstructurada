#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct sEmpleado{

    int codVendedor;
    char *nombre[30];
    int objetivoTarjetasAnual;
    double sueldoAnual;

};typedef struct sEmpleado tEmpleado;

struct s_ventas{
    int codigoVendedor;
    char nombreMes[15];
    int cantidadDeTarjetas;
}

struct sNodoBin{

    tEmpleado empleado;
    sNodoBin * nodoIzq;
    sNodoBin * nodoDer;

};typedef struct sNodoBin tNodoBin;

int liquidar( tNodoBin arbol, int idVen );
int cargarArbolVendedores ( tNodoBin* arbol, FILE* fVende );
void cargarVendedorAlArbol( tEmpleado, tNodoBin*);
void enOrden(tNodoBin arbol);

int main()
{

    return 0;
}

int liquidar( tNodoBin arbol, int idVen ){

    FILE* arch = fopen( "ventasTrjetas.dat", "rb");
    tEmpleado empleado = ObtenerInfoEmpleadoPorId(arbol,idVen);
    int TarjetasVendidas = ObtenerTrjetasVendidasPorId( idVen);
    if( arch != NULL){

        if ( empleado.codVendedor == 0){
            printf(" No existe el vendedor!\n");
        }else{

            printf("Vendedor: %s\n",empleado.nombre);
            printf("ID: %d\n", empleado.codVendedor);
            printf("Total de tarjetas vendidas: %d\n", TarjetasVendidas);
            printf("Objetivo Anual: %d\n", tEmpleado.objetivoTarjetasAnual);

        }
        fclose(arch);
    }

}
tEmpleado ObtenerInfoEmpleadoPorId( tNodoBin arbol, int idVen ){

    if( arbol!=NULL ){
        ObtenerInfoEmpleadoPorId(arbol->nodoIzq);
        if ( (arbol->empleado).codVendedor == idVendedor){
            return arbol->empleado;
        }
        else{
            ObtenerInfoEmpleadoPorId(arbol->nodoDer);
        }
    }
}



int cargarArbolVendedores ( tNodoBin* arbol, FILE* fVende ){

    tEmpleado aux;
    char *arr = NULL;
    arr = malloc( sizeof(char));9
    char c;
    int i;

    if( fVende!=NULL ){

        while( fscanf(fvende, "%d,",&(aux.codVendedor)))!=EOF ){
            i=0;
            c = fgetc(fVende);

            while( c!=','){
                arr[i]=c;
                i++;
                arr = realloc(arr,sizeof(char)*(i+1))
                fgetc(fvende);
            }
        strcpy(aux.nombre,arr);
        fscanf(fvende,"%d",&(aux.objetivoTarjetasAnual));
        fscanf(fvende,"%d",&(aux.sueldoAnual));

        cargarVendedorAlArbol(arbol, aux);
        }
    }
    return 0;
}

void cargarVendedorAlArbol(tNodoBin* arbol, tEmpleado aux ){

    if( arbol==NULL ){
        (*arbol) = malloc(sizeof(tNodoBin));
        (*arbol)->empleado = aux;
        (*arbol)->nodoDer = NULL;
        (*arbol)->nodoIzq = NULL;
    }
    else{
        if( aux.codVendedor < ((*arbol)->nodoIzq).codVendedor ){
            cargarVendedorAlArbol(&((*arbol)->nodoIzq),aux);
        }
        else if( aux.codVendedor > ((*arbol)->nodoIzq).codVendedor ){
            cargarVendedorAlArbol(&((*arbol)->nodoDer),aux);
        }
    }
}

void enOrden(tNodoBin arbol){

    if( arbol!=NULL ){
        enOrden(arbol->nodoIzq);
        printf("%d\n",arbol->empleado.codVendedor)
        enOrden(arbol->nodoDer);
    }

}


