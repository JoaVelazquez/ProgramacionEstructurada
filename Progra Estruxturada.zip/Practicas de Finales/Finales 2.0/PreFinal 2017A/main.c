#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
/*
void CargarString ( char** str);

int main(){

    char*ar = NULL;
    printf("Cargue su arreglo:\n");
    CargarString(*ar);
    return 0;
}

void CargarString ( char** str){

    int i=0;
    char aux;
    *str = malloc(sizeof(char));
    aux = getche();

    while ( aux!='\r'){

        *((*str)+i) = aux;
        i++;
        *str = realloc( *str, sizeof(char)*(i+1));
        aux = getche();

    }
    *((*str)+i) = '\0';

}

void ordenar( t_per** per);

void main(){

    return 0;
}

void ordenar( t_per** per){

    int i=0,j=0;
    t_per aux;
    for ( i=0 ; *((*per)+i).dni!=0 ; i++){
        for ( j=i+1 ; *((*per)+j).dni!=0 ; i++){
            if ( *((*per)+i).dni < *((*per)+j).dni ){
                aux = per+i;
                per+i = per+j;
                per+j = aux;
            }
        }
    }
}
/* 2.1) OPCION H (ninguna de las anteriores)
   2.2) OPCION A (0,0)
   2.3) OPCION F ( error de compilacion, no hace malloc/realloc )
   2.4) OPCION E (retorna  0)

*/
