#include <stdio.h>
#include <stdlib.h>
int* minimoDir (int *v);
/*
int main()
{
    int ar[] = {5,9,3,6,0};
    int * min= minimoDir(ar);
    printf("%d",*min);
    return 0;
}

int* minimoDir (int *v){
    int * min,*x,*m;
    x = v;
    min = x;
    if( (*v)!=0 ){
        v = v++;
        m = minimoDir(v);
        if ( *m < *x && *m!=0 ){
            min = m;
        }
    }

    return min;
}
*/
/* 2.1) OPCION E (6)
   2.2) OPCION E (14)
   2.3) OPCION E ( error de compilacion )
   2.4) OPCION E (81)

*/
