#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int* minimoDir ( int* v );
/*EJERCICIO 1.1
int main()
{
    int ar[] = {5,9,3,6,0};
    int * min= minimoDir(ar);
    printf("%d",*min);
    return 0;
}

int* minimoDir ( int* v ){

    int *min,*x,*m;
    x = v;
    min = x;
    if ( *(v)!=0 ){
        v++;
        m = minimoDir( v );
        if ( *m < *x && *m!=0 ){
            min = m ;
        }
    }
    return min;
}
/*
/*EJERCICIO 1.2
int bit( unsigned int n);

int main(){

    unsigned int n=-536870905;
    printf("%d",bit(n));
    return 0;
}

int bit( unsigned int n){

    unsigned int mask1 = 7;
    unsigned int mask2 = 7<<29;
    if ( n&(mask1|mask2) == (mask1|mask2)){
        return 1;
    }
    else{
        return 0;
    }
}
*/
/* 2.1) OPCION D (7)
   2.2) OPCION E (22)
   2.3) OPCION E ( error de compilacion )
   2.4) OPCION H (retorna 0)

*/


