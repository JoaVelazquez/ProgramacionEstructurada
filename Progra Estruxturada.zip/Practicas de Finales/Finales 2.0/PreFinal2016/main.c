#include <stdio.h>
#include <stdlib.h>
/*EJERCICIO 1.14
int* cargarArr();

int main()
{

    return 0;
}

int* cargarArr(){

    int *arr = NULL,i=0,n=0;
    arr = malloc(sizeof(int));
    printf("Ingrese numeros: ");
    scanf("%d",&n);
    *(arr) = n;

    while( n!=0 ){

        printf("Ingrese numeros: ");
        scanf("%d",&n);
        i++;
        arr = realloc(arr, sizeof(int)*(i+1)); ;
        *(arr+i) = n;

    }
    return arr;

}
*/
int main()
{
    int arr[6] = {1,3,2,4,9,0};
    printf("%d",sumPares(arr));
    return 0;
}

int sumPares( int * arr){

    if(*arr!=0){

        if( (*arr)%2 == 0){
            return (*arr) + sumPares(arr+1);
        }
        else{
            return 0 + sumPares(arr+1);
        }
    }

    return 0;
}

/*
    2.1)E (0)
    2.2)B ('b')
    2.3)E (error compilacion)
    2.4)E (14)
*/



