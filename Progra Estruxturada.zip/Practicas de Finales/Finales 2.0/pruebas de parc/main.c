#include <stdio.h>
#include <string.h>

typedef struct datos{
  char* titulo;
  char * tipoDeSolicitud;
  char* nombreDeUsuario;
  char* ipHost;
  char* tiempo;
}datos_t;

int validarSolicitud(datos_t datos){

  int longitud = 0;
  int respuesta = 0;

  longitud += strlen(datos.titulo);
  longitud += strlen(datos.tipoDeSolicitud);
  longitud += strlen(datos.ipHost);
  longitud += strlen(datos.tiempo);
  longitud += strlen(datos.nombreDeUsuario);

  if (longitud <=96){
    respuesta = 1;
  }

  return respuesta;
}

char* crearMensajeBienvenida(datos_t datos){
  return strcat(strcat(strcat(strcat(strcat("Hola ", datos.nombreDeUsuario)," del "),datos.ipHost)," Bienvenido al servidor de mensajes del "),datos.titulo);
}



int main(void) {
  datos_t datos;
  strcpy(datos.titulo, "parcial");
  strcpy(datos.ipHost, "172.192.98");
  strcpy(datos.nombreDeUsuario, "Nacho");

  char* mensaje = crearMensajeBienvenida(datos);
  printf("%s",mensaje);

  return 0;
}
