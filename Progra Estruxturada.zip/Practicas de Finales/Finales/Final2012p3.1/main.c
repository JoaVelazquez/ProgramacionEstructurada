#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct s_parcelas{
    int id_parcelas;
    int id_categoria;
    int tamanio;
    double valor;
};
typedef struct s_parcelas t_parcelas;

struct s_categoria{

    int id_categoria;
    char * descripcion;
    char * seccionJuridiccion;

};
typedef struct s_categoria t_categoria;

struct s_info{
    int ID_categoria;
    char descripcion[50];
    int Cant_parcelas;
};
typedef struct s_info t_info;


struct s_hoja{
    t_info informacion;
    struct s_hoja * izq;
    struct s_hoja * der;
};
typedef struct s_hoja * t_arbol;

void filtrarArchCat(t_categoria ** arreglo, char * nomArch);
void imprimirArbol(t_arbol arbol);
t_arbol carga_suma(char * ArchCat,char * ArchParce);
void filtrarArchPar(t_parcelas ** arreglo, char * nomArch);
void cargaArbol(t_arbol * arbol, t_info datos);
int main()
{

    t_arbol abb=NULL;
    abb= carga_suma("categorias.dat","parcelas.txt");

    //printf("\nCarga del Arbol:\n");
    imprimirArbol(abb);

    return 0;
}

void imprimirArbol(t_arbol arbol){

    if(arbol!=NULL){

        imprimirArbol(arbol->izq);
        printf("%d , %s ,%d\n",arbol->informacion.ID_categoria,arbol->informacion.descripcion,arbol->informacion.Cant_parcelas);
        imprimirArbol(arbol->der);

    }

}



t_arbol carga_suma(char * ArchCat,char * ArchParce){

    t_arbol arbol= NULL;
    t_categoria * arregloCategoria= NULL;
    t_parcelas * arregloParcelas=NULL;
    t_info auxiliar;
    int id;
    int suma=0;

    filtrarArchPar(&arregloParcelas,ArchParce);
    filtrarArchCat(&arregloCategoria,ArchCat);


    for(int i=0;(arregloCategoria[i].id_categoria)!=0;i++){

        auxiliar.ID_categoria = arregloCategoria[i].id_categoria;
        strcpy(auxiliar.descripcion,arregloCategoria[i].descripcion);
        printf("\n\n%s\n",arregloCategoria[i].descripcion);
        suma=0;

        for(int j=0;arregloParcelas[j].id_categoria!=0;j++){

            if( auxiliar.ID_categoria ==arregloParcelas[j].id_categoria){

                suma++;
            }
        }
        auxiliar.Cant_parcelas= suma;
        cargaArbol(&arbol,auxiliar);

    }

    return arbol;
}
void filtrarArchPar(t_parcelas ** arreglo, char * nomArch){
    t_parcelas auxiliar;
    t_parcelas elementoParada;
    int contador=0;
    FILE * archivo;
    archivo= fopen(nomArch,"r");


    elementoParada.id_categoria=0;
    elementoParada.id_parcelas=0;
    elementoParada.tamanio=0;
    elementoParada.valor=0;




    if(archivo!=NULL){
        *arreglo=malloc(sizeof(t_parcelas));
        while(fscanf(archivo,"%d,%d,%d,%lf\n",&auxiliar.id_parcelas,&auxiliar.id_categoria,&auxiliar.tamanio,&auxiliar.valor)!=EOF){
                printf("%d,%d,%d,%lf\n",auxiliar.id_parcelas,auxiliar.id_categoria,auxiliar.tamanio,auxiliar.valor);

                *(*arreglo+contador)=auxiliar;
                contador++;
                *arreglo=realloc(*arreglo,sizeof(t_parcelas)*(1+contador));

        }
        *(*arreglo+contador)=elementoParada;

    }

    printf("\n\n");







}
void filtrarArchCat(t_categoria ** arreglo, char * nomArch){
    FILE * archivo;
    archivo=fopen(nomArch,"rb");
    int contador=0;
    t_categoria auxiliar;
    t_categoria elementoParada;


    elementoParada.id_categoria=0;
    elementoParada.descripcion=NULL;
    elementoParada.seccionJuridiccion=NULL;



    if(archivo!=NULL){
        //printf("Entre");
        *arreglo=malloc(sizeof(t_categoria));
        while(fread(&auxiliar,sizeof(t_categoria),1,archivo)!=0){
            *(*arreglo+contador)= auxiliar;
            contador++;
            *arreglo=realloc(*arreglo,sizeof(t_categoria)*(contador+1));

        }
        *(*arreglo+contador)=elementoParada;
    }
}
void cargaArbol(t_arbol * arbol, t_info datos){


    if(*arbol == NULL){
        (*arbol)=malloc( sizeof(struct s_hoja));
        (*arbol)->informacion=datos;
        (*arbol)->der=NULL;
        (*arbol)->izq=NULL;
    }
    else if(datos.ID_categoria > (*arbol)->informacion.ID_categoria){
        cargaArbol(&(*arbol)->der,datos);
    }
    else{
        cargaArbol(&(*arbol)->izq,datos);
    }

}
