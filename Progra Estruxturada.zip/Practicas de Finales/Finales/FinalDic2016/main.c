#include <stdio.h>
#include <stdlib.h>
// PARTE 1 EJERCICIO 1
/*
int* cargarArr();
void imprimirArreglo(int * arreglo);
int main()
{
    int * arreglo;
    arreglo = cargarArr();
    imprimirArreglo(arreglo);
    return 0;
}

int* cargarArr(){

    int* arr= NULL, i=0,n=0;
    arr= malloc(sizeof(int));
    printf("Ingrese numeros: ");
    scanf("%d",&n);
    *(arr)=n;
    while(n!=0){
        printf("ingrese numeros: ");
        scanf("%d",&n);
        i++;
        arr= realloc(arr,sizeof(int)*(i+1));
        *(arr+i)=n;
    }
    return arr;

}
void imprimirArreglo(int * arreglo){

    for(int i=0; arreglo[i]!=0; i++){
        printf(" %d ",arreglo[i]);
    }



}*/

//PARTE 1 EJERCICIO 2

/*int sumPares(int * arr);
int main(){

    int arreglo[8]= {1,3,4,6,7,3,0};
    printf("%d",sumPares(arreglo));
    return 0;

}
int sumPares(int * arr){

    if((*arr)!=0){
        if(*(arr)%2==0){
            return *(arr)+ sumPares(arr+1);
        }
        else{
            return sumPares(arr+1);
        }


    }
    return 0;
}*/
//char f(char a);
int main(){

    //unsigned char a=1;
    //unsigned int i;
    //for(i=0; i< 8;i++){
      //  a=a&(1<<i);
    //}
    //printf("\n%d",a);

    f();




}

/*char f(char a){

    if(a<'c'){
        printf("a<c");
        f(a+1);

    }else{
        if(a=='b'){
            printf("a==b");
            f(a+1);
        }
    }
    return a;
}*/
void f(){
    int a=9, b=13;
    int *bb, **cc;

    bb=&b;
    cc=&bb;
    printf("%d",*bb+1);

}
