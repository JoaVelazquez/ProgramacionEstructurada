 #include <stdio.h>
#include <stdlib.h>
#include <string.h>


struct v{
    int cod;
    char nom[30];
    int objetivo;
    double sueldoAnual;
};
typedef struct v vendedores;
struct sNodoBin
{
    vendedores info;
    struct sNodoBin * izq;
    struct sNodoBin * der;
};
typedef struct sNodoBin * tNodoBin;
int cargarArbolVendedores(tNodoBin * arbol, FILE * fvende);
void agregarArbol(tNodoBin* arbol,vendedores aux);
void inorder(tNodoBin arbol);
int main()
{
    tNodoBin arbol= NULL;
    FILE* arch;
    arch= fopen("vendedores.txt","r");
    cargarArbolVendedores(&arbol,arch);
    inorder(arbol);
    return 0;
}

int cargarArbolVendedores(tNodoBin * arbol, FILE * fvende){

    vendedores auxiliar;
    char  arreglo[30];
    char c;
    int i;
    if(fvende!=NULL){
        while(fscanf(fvende,"%d,",&(auxiliar.cod))!=EOF){
            i=0;
            c= fgetc(fvende);

            while(c!=','){
                arreglo[i]=c;
                i++;
                c=fgetc(fvende);
            }
            strcpy(auxiliar.nom,arreglo);

            fscanf(fvende,"%d,",&(auxiliar.objetivo));
            fscanf(fvende,"%lf\n",&(auxiliar.sueldoAnual));

            agregarArbol(arbol,auxiliar);
        }
    }
    return 0;

}
void agregarArbol(tNodoBin* arbol,vendedores aux){

    if(*arbol==NULL){
        (*arbol)= malloc(sizeof(struct sNodoBin));
        (*arbol)->info= aux;
        (*arbol)->der= NULL;
        (*arbol)->izq= NULL;
    }
    else{
        if(aux.cod < ((*arbol)->info).cod){

            agregarArbol(&((*arbol)->izq),aux);

        }
        else{

            agregarArbol(&((*arbol)->der),aux);

        }
    }
}

void inorder(tNodoBin arbol){

    if(arbol!=NULL){
        inorder(arbol->izq);
        printf("%d\n %s",arbol->info.cod, arbol->info.nom);
        inorder(arbol->der);

    }
}

