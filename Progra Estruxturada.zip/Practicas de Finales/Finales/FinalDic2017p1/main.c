#include <stdio.h>
#include <stdlib.h>
int * minimoDir(int*v);
//int main()
//{
    //int arreglo[6]={3,10,12,1,4,0};
    //printf("%d",*minimoDir(arreglo));

  //  printf("%d\n",bit(4));

    //return 0;
//}
/*int * minimoDir(int*v){
    int * min= NULL;
    int * aux= v;
    int * retorno= NULL;

    if(*v!=0)
    {
        min= minimoDir(v+1);

        if(min==NULL){
            retorno= aux;
        }
        else{
            if(*min > *aux){
                retorno=aux;
            }
            else{
                retorno=min;
            }
        }
    }
    return retorno;
}*/
/*int bit(unsigned int n){
    unsigned int mask1= 3; //2^2-1 = 00000011
    unsigned int mask2= mask1<<30;

    if( ((mask1|mask2)^n )==0 ){
        return 1;
    }
    else{
        return 0;
    }
}*/

void sum(int arr[]){

    arr[0]= arr[0]+3 ;

}
void resta(int a){

    a=a-4;

}
void f(){
    int a=9,b=13;
    int*bb,**cc;
    bb=&b;
    cc=&bb;
    printf("%d\n",*bb+1);
}
int foo(int n,int m){
    int miFoo=1;
    if(m>0){
        miFoo=n*foo(n,m-1);
    }
    return miFoo;

}


int main(){

    int a[3]={3,2,13};int num=0;
    sum(a);
    resta(num);
    printf("%d\n",a[0]+num);

    f();


    printf("%d",foo(3,4));


    return 0;
}
