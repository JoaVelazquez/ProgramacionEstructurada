#include <stdio.h>
#include <stdlib.h>

struct estructuraDatos{
    int nro_registro;
    char * nombre;
    char * apellido;
};
typedef struct estructuraDatos t_datos;

struct sNodoBin
{
    t_datos alumno;
    struct sNodoBin * izq;
    struct sNodoBin * der;
};
typedef struct sNodoBin * tNodoBin;
void unificar(char * arch1,char * arch2);
void filtrarArchivo(char* nomArch,t_datos ** arregloAlumnos);
int main()
{
    unificar("comisionAM.csv","comisionBM.csv");
    return 0;
}

void unificar(char * arch1,char * arch2){
    tNodoBin arbol =NULL;
    t_datos * comisionA;
    t_datos * comisionB;
    t_datos * arregloTotal;
    int i=0;
    FILE * arch;
    arch= fopen("comisiones.csv","w");

    filtrarArchivo(arch1,&comisionA);
    filtrarArchivo(arch2,&comisionB);

    armarConjunto(comisionA, comisionB,&arregloTotal);

    while(arregloTotal[i].nro_registro!=0){
        //printf("\n%s\t",arregloTotal[i].nombre);
        agregarArbol(&arbol,arregloTotal[i]);
        i++;
    }
    grabarArchivoConjunto(arch,arbol);



}

void agregarArbol(tNodoBin * arbol,t_datos alum){

    if(*arbol == NULL){
        (*arbol)= malloc(sizeof(struct sNodoBin));
        (*arbol)->alumno= alum;
        (*arbol)->der= NULL;
        (*arbol)->izq= NULL;
        printf("Cargo %d",alum.nro_registro);
    }
    else{

        if(alum.nro_registro< ((*arbol)->alumno).nro_registro){

                agregarArbol(&((*arbol)->izq),alum);

        }
        else if(alum.nro_registro> ((*arbol)->alumno).nro_registro){
                agregarArbol(&((*arbol)->der),alum);
        }
    }
}

void grabarArchivoConjunto(FILE * arch,tNodoBin arbol){

    if(arbol!=NULL){
        printf("entro");
        grabarArchivoConjunto(arch,arbol->izq);
        printf(arch,"\n\n%d,%s,%s\n",arbol->alumno.nro_registro,arbol->alumno.apellido,arbol->alumno.nombre);
        fprintf(arch,"%d,%s,%s\n",arbol->alumno.nro_registro,arbol->alumno.apellido,arbol->alumno.nombre);
        grabarArchivoConjunto(arch,arbol->der);

    }
}

void filtrarArchivo(char* nomArch,t_datos ** arregloAlumnos){
    t_datos aux;
    FILE* archivo;
    archivo=fopen(nomArch,"r");
    char caracter;
    t_datos elementoParada;
    elementoParada.nro_registro=0;
    elementoParada.nombre=NULL;
    elementoParada.apellido=NULL;

    int i=0;
    int contador=0;

    if(archivo!=NULL){

            *arregloAlumnos= malloc(sizeof(t_datos));
            while(fscanf(archivo,"%d,",&(aux.nro_registro))!=EOF){

                i=0;
                aux.nombre=malloc(sizeof(char));
                caracter=fgetc(archivo);
                while(caracter!=','){
                    *(aux.nombre +i)=caracter;
                    i++;
                    aux.nombre=realloc(aux.nombre,sizeof(char)*(i+1));
                    caracter=fgetc(archivo);
                }
                *(aux.nombre+i)='\0';

                aux.apellido= malloc(sizeof(char));
                i=0;
                caracter=fgetc(archivo);

                while(caracter!='\n'){
                    *(aux.apellido +i)= caracter;
                    i++;
                    aux.apellido= realloc(aux.apellido,sizeof(char)*(i+1));
                    caracter= fgetc(archivo);

                }
                *(aux.apellido+i)='\0';


                *(*arregloAlumnos+ contador)=aux;
                contador++;
                *arregloAlumnos= realloc(*arregloAlumnos,sizeof(t_datos)*(contador+1));
        }
        *(*arregloAlumnos + contador)=elementoParada;
    }
}
void armarConjunto(t_datos * comA,t_datos * comB, t_datos ** conjunto){
    int i=0;
    int contador=0;
    t_datos auxiliar;
    auxiliar.nro_registro=0;
    auxiliar.apellido=NULL;
    auxiliar.nombre=NULL;

    *conjunto = malloc(sizeof(t_datos));
    while(comA[i].nro_registro!=0){
        printf("%s\n",comA[i].nombre);
        *(*conjunto +contador)= comA[i];
        contador++;
        i++;
        *conjunto= realloc(*conjunto,sizeof(t_datos)*(contador+1));
    }
    i=0;
    while(comB[i].nro_registro!=0){
        printf("%s\n",comB[i].nombre);
        *(*conjunto+contador)=comB[i];
        contador++;
        i++;
        *conjunto=realloc(*conjunto,sizeof(t_datos)*(contador+1));
    }

    *(*conjunto+contador)= auxiliar;

}
