  sa#include <stdio.h>
#include <stdlib.h>
#include <string.h> 

struct s_nota{
    int valor;
    struct s_nota * sig;
};
typedef struct s_nota * t_nota;

struct s_alu{
    char* apellido;
    t_nota lstNota;
    struct s_alu*sig;
};
typedef struct s_alu * t_alu;
struct arr{
    char* apellido;
    int promedio;
};
typedef struct arr t_arreglo;


void agregarAlumno(t_alu *,char*);
void agregarNota(t_nota *,int);
void imprimirNotas(t_arreglo* listaAlumnos);
void ordenarArreglo(t_arreglo ** alumnos);
int main()
{
    t_alu listaAlumnos=NULL;
    t_arreglo * arregloAlumnos;

    agregarAlumno(&listaAlumnos,"Paredes");
    agregarAlumno(&listaAlumnos,"Tornati");
    agregarAlumno(&listaAlumnos,"Saavedra");

    agregarNota(&(listaAlumnos->lstNota), 2);
    agregarNota(&(listaAlumnos->lstNota), 6);
    agregarNota(&(listaAlumnos->lstNota), 4);
b 

    agregarNota(&(listaAlumnos->sig->lstNota), 9);
    agregarNota(&(listaAlumnos->sig->lstNota), 8);
    agregarNota(&(listaAlumnos->sig->lstNota), 7);

    agregarNota(&(listaAlumnos->sig->sig->lstNota), 5);
    agregarNota(&(listaAlumnos->sig->sig->lstNota), 4);
    agregarNota(&(listaAlumnos->sig->sig->lstNota), 2);

    printf(" Apellido \t Notas\n\n");
    armarArregloAlumnos(&arregloAlumnos,listaAlumnos);
    ordenarArreglo(&arregloAlumnos);
    imprimirNotas(arregloAlumnos);

    return 0;
}
void agregarAlumno(t_alu * direccionAlumno, char * apellido){

    if(*direccionAlumno==NULL){
        (*direccionAlumno)=malloc(sizeof(struct s_alu));
        (*direccionAlumno)->apellido= apellido;
        (*direccionAlumno)->lstNota= NULL;
        (*direccionAlumno)->sig = NULL;
    }
    else{

        agregarAlumno(&((*direccionAlumno)->sig),apellido);

    }
}
void agregarNota(t_nota * direccionNota,int nota){

    if(*direccionNota==NULL){
        (*direccionNota)=malloc(sizeof(struct s_nota));
        (*direccionNota)->valor= nota;
        (*direccionNota)->sig= NULL;
    }
    else{
        agregarNota(&((*direccionNota)->sig),nota);
    }
}
int obtenerPromedioAlumnos(t_nota listaNotas){
    int sumaNotas;
    int cantNotas;
    int promedio=0;
    sumaNotas= obtenerSumaDeNotas(listaNotas);
    cantNotas=obtenerCantidadNotas(listaNotas);

    if(cantNotas!=0){
        promedio= sumaNotas/cantNotas;
    }
    return promedio;

}

int obtenerCantidadNotas(t_nota listaNotas){

    if(listaNotas!=NULL){
        return 1+ obtenerCantidadNotas(listaNotas->sig);

    }
    else
        return 0;

}

int obtenerSumaDeNotas(t_nota listaNotas){

    if(listaNotas!=NULL){
        return listaNotas->valor + obtenerSumaDeNotas(listaNotas->sig);
    }
    else{
        return 0;
    }

}

void imprimirNotas(t_arreglo* listaAlumnos){



    //if (listaAlumnos!=NULL){
      //  printf("%10s%10d\n\n",listaAlumnos->apellido,obtenerPromedioAlumnos(listaAlumnos->lstNota));
        //imprimirNotas(listaAlumnos->sig);
    //}
    for(int i=0;listaAlumnos[i].promedio!=0;i++){
        printf("%10s%10d\n",listaAlumnos[i].apellido,listaAlumnos[i].promedio);

    }

}

void armarArregloAlumnos(t_arreglo ** alumnos,t_alu listaAlumnos){
    int i=0;
    *alumnos= malloc(sizeof(t_arreglo));
    t_arreglo aux;
    t_arreglo elementoParada;

    elementoParada.apellido=NULL;
    elementoParada.promedio=0;

     while(listaAlumnos!=NULL){
            aux.apellido = listaAlumnos->apellido;
            aux.promedio = obtenerPromedioAlumnos(listaAlumnos->lstNota);
            *(*alumnos+i)=aux;
            i++;
            *alumnos=realloc(*alumnos,sizeof(t_arreglo)*(i+1));
            listaAlumnos=listaAlumnos->sig;
     }

    *(*alumnos+i)= elementoParada;

}
void ordenarArreglo(t_arreglo ** alumnos){
    t_arreglo auxiliar;
    int i;
    int j;

    for(i=0;(*alumnos+i)->promedio!=0;i++){
        for(j=i;(*alumnos+j)->promedio!=0;j++){
            if((*alumnos+j)->promedio > (*alumnos+i)->promedio){
                auxiliar= *(*alumnos+i);
                *(*alumnos+i)=*(*alumnos+j);
                *(*alumnos+j)=auxiliar;

            }
        }
    }

}
