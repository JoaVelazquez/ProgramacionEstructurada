#include <stdio.h>
#include <stdlib.h>

struct s_indice{
    int posInicial;
    int posFinal;
};
typedef struct s_indice t_indice;

t_indice buscarSub(char * str,char * sub);
int contarLargoStr(char * str);
int main()
{
    char cadena[] = "La verdad absoluta no existe, y esto es absolutamente cierto.";
    char sub[]= "r";
    t_indice pos;
    pos=buscarSub(cadena,sub);
    printf("\nPosicion inicial %d y posicion final %d\n",pos.posInicial,pos.posFinal);
    return 0;
}


t_indice buscarSub(char * str,char * sub){

    t_indice posiciones;
    posiciones.posFinal=0;
    posiciones.posInicial=0;
    int i=0;
    int contadorPosicion;
    int contadorSubstring;
    int largoSubstring= contarLargoStr(sub);

    for(contadorPosicion=0;str[contadorPosicion]!='\0';contadorPosicion++){
            if(str[contadorPosicion]==sub[i] && str[contadorPosicion + (largoSubstring-1)]== sub[largoSubstring-1]){
                    posiciones.posInicial=contadorPosicion;
                    posiciones.posFinal= contadorPosicion;
                    contadorSubstring=contadorPosicion ;


                    while(str[contadorSubstring]==sub[i] && i<largoSubstring){
                        i++;
                        //printf("%c",str[contadorSubstring]);
                        posiciones.posFinal= contadorSubstring ;
                        contadorSubstring++;
                    }

                }
    }

    return posiciones;
}

int contarLargoStr(char * str){
    int largoString=0;
    int contador=0;

    while(str[contador]!='\0'){
        largoString++;
        contador++;
    }
    return largoString;

}
