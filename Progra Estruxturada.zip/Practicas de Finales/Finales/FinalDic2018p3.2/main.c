#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
struct s_linea{
    int numLinea;
    int posInicial;
    int posFinal;
};
typedef struct s_linea linea;
struct s_indice{
    int posInicial;
    int posFinal;
};
typedef struct s_indice t_indice;
struct s_nodo{

    struct s_nodo* sig;
    linea informacion;
};
typedef struct s_nodo * t_nodo;

t_indice buscarSub(char * str,char * sub);
void filtrarArchivo(char *nomarchivo,t_nodo * lista,char* sub);
t_indice buscarSub(char * str,char * sub);
void cargarLista(char ** arregloFrases,t_nodo * lista,char * sub);
void agregarLista(t_nodo * lista, linea posiciones);
int contarLargoStr(char * str);
t_nodo indices(char* sub);
void imprimirLista(t_nodo lista);
int main()
{
    t_nodo lista=NULL;
    char sub[]="da";
    lista=indices(sub);

    imprimirLista(lista);
    return 0;
}
t_nodo indices(char * sub){
    t_nodo lista = NULL;


    filtrarArchivo("frases.txt",&lista,sub);


    return lista;


}

void filtrarArchivo(char * nomarchivo, t_nodo * lista, char * sub){
    FILE* archivo;
    archivo=fopen(nomarchivo,"r");
    char ** arregloFrases = NULL;
    char * arregloCaracteres=NULL;
    char c;
    char elementoParada='\0';
    int i=0;
    int contador=0;


    if(archivo!=NULL){
        arregloFrases= malloc(sizeof(char()));
        arregloCaracteres=malloc(sizeof(char));

        c=fgetc(archivo);

        while(c!=EOF){

            while(c!='\n'){

                arregloCaracteres[i]= c;
                i++;
                arregloCaracteres=realloc(arregloCaracteres,sizeof(char)*(i+1));
                c=fgetc(archivo);

            }
            arregloCaracteres[i]='\0';
            arregloFrases[contador] = arregloCaracteres;
            contador++;
            arregloFrases=realloc(arregloFrases,sizeof(char* )*(contador+1));
            c=fgetc(archivo);
            i=0;
            arregloCaracteres=malloc(sizeof(char));
        }
        arregloCaracteres[0]='\0';
        arregloFrases[contador]=arregloCaracteres;
    }
    cargarLista(arregloFrases,lista,sub);
}

void cargarLista(char ** arregloFrases,t_nodo * lista,char * sub){
    t_indice auxiliar;
    linea aux;

    for(int i =0;arregloFrases[i][0]!='\0';i++){
        //printf("%s\n",arregloFrases[i]);
        auxiliar=buscarSub(arregloFrases[i],sub);
        if(auxiliar.posFinal!=-1 && auxiliar.posInicial!=-1){
            //printf("%d   %d",auxiliar.posInicial,auxiliar.posFinal);
            aux.numLinea=i;
            aux.posFinal= auxiliar.posFinal;
            aux.posInicial= auxiliar.posInicial;
            agregarLista(lista,aux);
        }
    }
}


t_indice buscarSub(char * str,char * sub){

    t_indice posiciones;
    posiciones.posFinal=-1;
    posiciones.posInicial=-1;
    int i=0;
    int contadorPosicion;
    int contadorSubstring;
    int largoSubstring= contarLargoStr(sub);

    for(contadorPosicion=0;str[contadorPosicion]!='\0';contadorPosicion++){
            if(str[contadorPosicion]==sub[i] && str[contadorPosicion + (largoSubstring-1)]== sub[largoSubstring-1]){
                    posiciones.posInicial=contadorPosicion;
                    posiciones.posFinal= contadorPosicion;
                    contadorSubstring=contadorPosicion + 1;
                    i= i+1;

                    while(str[contadorSubstring]==sub[i] && i<largoSubstring){
                        i++;
                        //printf("%c",str[contadorSubstring]);
                        posiciones.posFinal= contadorSubstring ;
                        contadorSubstring++;
                    }

                }
    }

    return posiciones;
}

int contarLargoStr(char * str){
    int largoString=0;
    int contador=0;

    while(str[contador]!='\0'){
        largoString++;
        contador++;
    }
    return largoString;

}

void agregarLista(t_nodo * lista, linea posiciones){

    if(*lista==NULL){
        (*lista)=malloc(sizeof(struct s_nodo));
        (*lista)->informacion= posiciones;
        (*lista)->sig=NULL;

    }
    else{

        agregarLista(&(*lista)->sig,posiciones);
    }


}
void imprimirLista(t_nodo lista){

    if(lista!=NULL){
        printf("%d,",lista->informacion.numLinea);
        printf("%d,",lista->informacion.posInicial);
        printf("%d\n",lista->informacion.posFinal);
        imprimirLista(lista->sig);
    }

}
