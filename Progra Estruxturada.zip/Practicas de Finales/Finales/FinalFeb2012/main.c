#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct s_parcelas{
    int id_parcelas;
    int id_categoria;
    int tamanio;
    double valor;
};
typedef struct s_parcelas t_parcelas;

struct s_categoria{

    int id_categoria;
    char * descripcion;
    char * seccionJuridiccion;

};
typedef struct s_categoria t_categoria;

struct s_info{
    int ID_categoria;
    char descripcion[50];
    int Cant_parcelas;
};
typedef struct s_info t_info;


struct s_hoja{
    t_info informacion;
    struct s_hoja * izq;
    struct s_hoja * der;
};
typedef struct s_hoja* t_arbol;

void verificoExistencia(t_info informacionRequerida ,t_categoria * arreglo);
int main()
{
    printf("Hello world!\n");
    return 0;
}

void verificacion(t_arbol arbol,t_categoria * arreglo){

    if(arbol!=NULL){

        verificacion(arbol->izq,arreglo);
        verificoExistencia(arbol->informacion,arreglo);
        verificacion(arbol->der,arreglo);
    }
}

void ArreCategoria(char* nomArch,t_categoria ** arreglo){
    int contador=0;
    FILE * archivo;
    t_categoria auxiliar;
    archivo=fopen(nomArch,"a+b");

    *arreglo=malloc(sizeof(t_categoria));

    while(fread(&auxiliar,sizeof(t_categoria),1,archivo)!=0){
        //arreglo[contador]=auxiliar;
        contador++;
        *(arreglo)=realloc(*arreglo,sizeof(t_categoria)*(contador+1));
    }
//    arreglo[contador]=elementoPar;

}
void verificoExistencia(t_info informacionRequerida ,t_categoria * arreglo){
    t_categoria auxiliar;
    int contador=0;

    for(int i =0; arreglo[i].id_categoria!=0;i++){
        if(informacionRequerida.ID_categoria==arreglo[i].id_categoria){
            contador++;
        }

    if(contador==0){

        auxiliar.id_categoria= informacionRequerida.ID_categoria;
        auxiliar.descripcion= informacionRequerida.descripcion;
        auxiliar.seccionJuridiccion="Desconocida";

        fwrite(&auxiliar,sizeof(t_categoria),1,"categorias.dat");
        }


    }
 }
