#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>



struct s_peliculas{
    int codPeli;
    char nom[80];
    int anio;
};
typedef struct s_peliculas t_peliculas;

struct s_actores{
    char apellido[50];
    char nombre[50];
    int codActor;
};
typedef struct s_actores t_actores;

struct s_pelact{
    int codPeli;
    int codActor;
};
typedef struct s_pelact hibrido;

void cargarArregloCodigo(hibrido ** arregloCodigo);
void funcion(int codigoActor);
int actorUnico(int codigoPelicula,hibrido * arregloCodigos);
t_peliculas buscarPelicula(int codigoPelicula);
void cargarArregloPelis(t_peliculas ** arreglo);

int main()
{
    printf("Hello world!\n");

    funcion(3000);

    return 0;
}

void funcion(int codigoActor){

    hibrido * arregloCodigo= NULL;
    cargarArregloCodigo(&arregloCodigo);
    t_peliculas auxiliar;

    for(int i =0 ; arregloCodigo[i].codActor!=0;i++){
        if( codigoActor== arregloCodigo[i].codActor){
                printf("Entre");
           if(actorUnico(arregloCodigo[i].codPeli,arregloCodigo)!=1 )
            {
                auxiliar=buscarPelicula(arregloCodigo[i].codPeli);
                printf("Nombre de la pelicula:%s\nAnio de estreno:%d\n\n",auxiliar.nom,auxiliar.anio);

            }

        }
    }
}

void cargarArregloCodigo(hibrido ** arregloCodigo){
    FILE * archivo=fopen("peliculas_actores.txt","r");
    hibrido auxiliar;
    hibrido elementoParada;
    int contador=0;
    int r;

    elementoParada.codActor=0;
    elementoParada.codPeli=0;

    if(archivo!=NULL){
        *arregloCodigo= malloc(sizeof(hibrido));

        while(fscanf(archivo,"%d,%d\n",&(auxiliar.codPeli),&(auxiliar.codActor))!=EOF){

            *(*arregloCodigo+contador)= auxiliar;
            contador++;
            *arregloCodigo=realloc(*arregloCodigo,(contador+1)*sizeof(hibrido));
        }
        *(*arregloCodigo+contador)=elementoParada;
    }




}
int actorUnico(int codigoPelicula,hibrido * arregloCodigos){
    int esUnico=0;
    int numeroActores=0;

    for(int i=0;arregloCodigos[i].codPeli!=0;i++){
        if(codigoPelicula == arregloCodigos[i].codPeli){
            numeroActores++;
        }
    }

    if(numeroActores!=1){
        esUnico=1;
    }

    return esUnico;

}

t_peliculas buscarPelicula(int codigoPelicula){
    t_peliculas peli;
    t_peliculas * arreglo =NULL;
    cargarArregloPelis(&arreglo);

    for(int i=0;arreglo[i].codPeli!=0;i++){
        if(codigoPelicula==arreglo[i].codPeli){

            peli= arreglo[i];

        }


    }



    return peli;

}

void cargarArregloPelis(t_peliculas ** arreglo){

    FILE * archivo= fopen("peliculas.dat","rb");
    t_peliculas aux;
    t_peliculas elementoParada;
    int contador=0;

    elementoParada.codPeli=0;



    if(archivo!=NULL){

        *arreglo= malloc(sizeof(t_peliculas));
        while(fread(&aux,sizeof(t_peliculas),1,archivo)!=0){
            *(*arreglo+contador)=aux;
            contador++;
            *arreglo=realloc(*arreglo,sizeof(t_peliculas)*(contador+1));
        }
        *(*arreglo+contador)= elementoParada;
    }
}
