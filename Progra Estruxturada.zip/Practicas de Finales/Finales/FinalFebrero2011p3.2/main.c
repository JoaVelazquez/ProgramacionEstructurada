#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct s_nodo{
    struct *  s_nodo izq;
    struct * s_nodo der;


};

struct s_peliculas{
    int codPeli;
    char nom[80];
    int anio;
};
typedef struct s_peliculas t_peliculas;

struct s_actores{
    char apellido[50];
    char nombre[50];
    int codActor;
};
typedef struct s_actores t_actores;

struct s_pelact{
    int codPeli;
    int codActor;
};
typedef struct s_pelact hibrido;


int main()
{
    funcion("Downey Jr",2008);
    return 0;
}

void funcion(char* apellido, int anio){
    hibrido * arregloHibrido=NULL;
    hibrido * arregloNuevoHibrido=NULL;
    t_actores * arregloActores=NULL;
    t_peliculas * arregloPeliculas=NULL:
    int contador=0;
    cargarArregloPeliculas(&arregloPeliculas,anio);
    cargarArregloActores(&arregloActores,apellido);
    cargarNuevoArreglo(&arregloNuevoHibrido,arregloPeliculas,arregloHibrido);

    free(arregloHibrido)

    cargarArregloAImprimir(&arregloNuevoHibrido,arregloActores,arregloNuevoHibrido);
    t_peliculas auxiliar;

    for(int i=0; arregloNuevoHibrido[i].codActor!=0;i++){
        for(int j=0;arregloNuevoHibrido[j].codActor!=0;j++){
            if(arregloNuevoHibrido[i].codActor==arregloNuevoHibrido[j].codActor){

                auxiliar=traerPelicula(arregloNuevoHibrido[j],arregloPeliculas);
                printf("%s, %d",auxiliar.nom,auxiliar.anio);
            }

        }
    }




}
void cargarArregloAImprimir(hibrido ** arreglonuevo,t_actores arregloActores,hibrido arregloHibrido){
    int contador=0;
    hibrido elementoParada;

    for(int i=0;arregloActores[i].codActor!=0;i++){
        for(int j=0; arregloHibrido[j].codActor!=0;i++){
            if(arregloActores[i].codActor==arregloHibrido[j].codActor){
                *(*arreglonuevo+contador)=arregloHibrido[j];
                contador++;
                *arreglonuevo=realloc(*arreglonuevo,sizeof(hibrido)*(contador+1));


            }
        }
    }
    *(*arreglonuevo+contador)= elementoParada;


}



void cargarNuevoArreglo(hibrido ** arreglo, t_peliculas * arreglopel,hibrido * arregloHibrido ){

    int i=0;
    int contador=0;
    hibrido elementoParada;
    elementoParada.codActor=0;
    elementoParada.codPeli=0;

    for(i=0; arreglopel[i].codPeli!=0;i++){
        for(j=0;arregloHibrido[j].codPeli!=0;j++){
            if(arreglopel[i].codPeli==arregloHibrido[j].codPeli){

                *(*arreglo+contador)= arregloHibrido[j];
                contador++;
                *arreglo=realloc(*arreglo,sizeof(hibrido)*(contador+1));
            }
        }
    }
    *(*arreglo+contador)=elementoParada;









}


void cargarArregloPeliculas(t_peliculas ** arreglo, int anio){
    FILE * archivo;
    archivo=fopen("peliculas.dat","rb");
    t_peliculas auxiliar;
    t_peliculas elementoParada;
    int contador=0;

    elementoParada.codPeli=0;



    if(archivo!=NULL){
        *arreglo= malloc(sizeof(t_peliculas));
        while(fread(&auxiliar,sizeof(t_peliculas),1,archivo)!=0){

            if(auxiliar.anio>anio){
                *(*arreglo+contador)= auxiliar;
                contador++;
                *arreglo=realloc(*arreglo,sizeof(t_peliculas)*(contador+1));
            }
        }
        *(*arreglo+contador)=elementoParada;


    }




}

void cargarArregloHibrido(hibrido ** arregloCodigos){
    hibrido auxiliar;
    hibrido elementoParada;
    int contador=0;
    FILE * archivo= fopen("peliculas_actores.txt","r");


    elementoParada.codActor=0;
    elementoParada.codPeli=0;


    if(archivo!=NULL){

        *arregloCodigos= malloc(sizeof(hibrido));
        while(fscanf(archivo,"%d,%d\n",&auxiliar.codActor,&auxiliar.codPeli)!=EOF){
            *(*arregloCodigos+contador)= auxiliar;
            ++contador;
            *arregloCodigos=realloc(*arregloCodigos,sizeof(hibrido));
        }
        *(*arregloCodigos+contador)= elementoParada;

    }

}

void cargarArregloActores(t_actores ** arregloActores, char* apellido){

    FILE* archivo=fopen("actores.dat","rb");
    t_actores auxiliar;
    t_actores elementoParada;
    int contador=0;

    elementoParada.codActor=0;


    if(archivo!=NULL){
        *arregloActores=malloc(sizeof(t_actores));
        while(fread(&auxiliar,sizeof(t_actores),1,archivo)!=0){

            if(strcmp(auxiliar.apellido,apellido)==0){
                *(*arregloActores+contador)= auxiliar;
                contador++;
                *arregloActores=realloc(*arregloActores,sizeof(t_actores)*(contador+1));
            }

        }
        *(*arregloActores+contador)= elementoParada;


    }


}
