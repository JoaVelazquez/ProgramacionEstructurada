#include <stdio.h>
#include <stdlib.h>

struct s_notas{
    int notas;
    int cantidadNotas;
};
typedef struct s_notas t_notas;

struct s_promedio{
    int nro_registro;
    char nombreMateria[250];
    unsigned int notas[10];
};
typedef struct s_promedio t_promedio;

struct s_alumno{
    int nro_registro;
    char * nombre;
    double promGeneral;
};
typedef struct s_alumno t_alumno;

void cargarArchivo(t_alumno * arreglo,char * nomArch);
void promedio(char * nomArch1,char* nomArch2);
double generarPromedio(int notas, int cantNotas);
void cargarArreglo(t_promedio** arreglo, char* nombreArchivo);
void cargarArregloAlumnos(t_alumno ** arreglo, char * nombreArchivo);
t_notas buscarNotas(unsigned int notas[10]);
int main()
{
    printf("Hello world!\n");
    return 0;
}

void promedio(char * nomArch1,char* nomArch2){
    t_alumno * arregloAlumnos=NULL;
    t_promedio * arreglo=NULL;
    t_alumno* arregloCarga=NULL;
    t_notas aux;
    t_alumno auxiliar;
    t_alumno parada;
    int sumaNotas=0;
    int cantNotas=0;
    int contador=0;



    parada.nro_registro=0;

    cargarArreglo(&arreglo,nomArch2);
    cargarArregloAlumnos(&arregloAlumnos,nomArch1);





    arregloCarga=malloc(sizeof(t_alumno));
    for(int i=0 ;arregloAlumnos[i].nro_registro!=0;i++){
        auxiliar.nro_registro= arregloAlumnos[i].nro_registro;
        auxiliar.nombre= arregloAlumnos[i].nombre;

        for(int j=0;arreglo[i].nro_registro!=0;j++){
            if(arregloAlumnos[i].nro_registro == arreglo[j].nro_registro){

                aux= buscarNotas(arreglo[j].notas);
                sumaNotas= sumaNotas + aux.notas;
                cantNotas= cantNotas +aux.cantidadNotas;

            }

        }
        auxiliar.promGeneral=generarPromedio(sumaNotas,cantNotas);
        arregloCarga[contador]= auxiliar;
        contador++;
        arregloCarga=realloc(arregloCarga,sizeof(t_alumno)*(contador+1));

    }

    arregloCarga[contador]=parada;
    cargarArchivo(arregloCarga,nomArch1);

}
void cargarArchivo(t_alumno * arreglo,char * nomArch){
    FILE* archivo= fopen(nomArch,"w");

    for(int i=0; arreglo[i].nro_registro!=0 ; i++){

        fprintf(archivo,"%d,%s,%lf\n",arreglo[i].nro_registro,arreglo[i].nombre,arreglo[i].promGeneral);



    }

    fclose(archivo);


}

double generarPromedio(int notas, int cantNotas){

    return (notas/cantNotas);

}
void cargarArreglo(t_promedio** arreglo, char* nombreArchivo){
    FILE * archivo= fopen(nombreArchivo,"rb");
    t_promedio auxiliar;
    t_promedio parada;

    parada.nro_registro=0;

    int contador=0;


    *arreglo=malloc(sizeof(t_promedio));
    while(fread(&auxiliar,sizeof(t_promedio),1,archivo)!=0){
        *(*arreglo+contador)= auxiliar;
        contador++;
        *arreglo=realloc(*arreglo,sizeof(t_promedio)*(1+contador));
    }
    *(*arreglo+contador)=parada;

    fclose(archivo);
}
void cargarArregloAlumnos(t_alumno ** arreglo, char * nombreArchivo){
    FILE * archivo=fopen(nombreArchivo,"r");
    char c;
    t_alumno auxiliar;
    t_alumno parada;
    int contador=0;
    int i=0;
    int r;


    parada.nro_registro=0;

    if(archivo!=NULL){
        *arreglo= malloc(sizeof(t_alumno));

        while(fscanf(archivo,"%d,",&(auxiliar.nro_registro))!=EOF){
            auxiliar.nombre= malloc(sizeof(char));
            c=fgetc(archivo);
            while(c!=','){
                auxiliar.nombre[i]=c;
                i++;
                auxiliar.nombre=realloc(auxiliar.nombre,sizeof(char)*(i+1));
                c=fgetc(archivo);
            }
            auxiliar.nombre[i]='\0';

            r=fscanf(archivo,"%lf\n",&(auxiliar.promGeneral));

            *(*arreglo+contador)= auxiliar;
            contador++;
            *arreglo= realloc(*arreglo,sizeof(t_alumno)*(contador+1));

        }

        *(*arreglo+contador)= parada;

    }


    fclose(archivo);

}

t_notas buscarNotas(unsigned int notas[10]){
    int i=0;
    int snotas;
    t_notas auxiliar;

    for(i=0;notas[i]!=0;i++){
        snotas= snotas + notas[i];
    }

    auxiliar.cantidadNotas=i;
    auxiliar.notas= notas;


    return auxiliar;
}
