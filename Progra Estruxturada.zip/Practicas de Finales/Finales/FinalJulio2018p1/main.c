#include <stdio.h>
#include <stdlib.h>
int * minimoDir(int* v);
/*int main()
{
    int arreglo[6]={2,5,6,1,4,0};
    int * min= minimoDir(arreglo);
    printf("Retornar Direccion minima: %p , el numero es %d\n",min,*min);
    return 0;
}*/
int * minimoDir(int* v){

    int * min ,*m,*x;
    x=v;
    min=x;
    if(*v!=0){
        v++;
        m=minimoDir(v);
        if(*m<*x || *min==0){
            min=m;
        }
    }
    return min;
}
void suma(int arr[]){
    *arr= *arr +3;
}
void resta (int a){
    a=a-4;
}

void f(){
    int a=9;
    int b=13;
    int* ar[2];
    ar[0]=&a;
    ar[1]=&b;
    printf("%d , %p\n",ar[0],ar[0]);
    printf("%d , %p\n",ar[1],ar[1]);
    printf("%d",*ar[0]+*ar[1]);
}
int main(){
    int a[3]={3,2,13};
    int num=1;
    suma(a);
    resta(num);
    printf("%d\n",*a+num);
    f();

    return 0;
}
