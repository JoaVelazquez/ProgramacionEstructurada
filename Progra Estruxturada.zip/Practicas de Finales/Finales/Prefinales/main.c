#include <stdio.h>
#include <stdlib.h>
char x(char a);
int main()
{
    //printf("%d",doble(4));
    //unsigned char a;
    //a=~0<<((sizeof(char)*8)-1);
    //printf("%d",a);

   // char * ptrA= "Juan";
   // char * ptrB="Pedro";

   // ptrA = ptrA + 4;
   // for(;*ptrB!='\0';ptrB++){
   //     printf("%c",*ptrA);
   // }

    //printf("%c",x('a'));

  /*
    int a=9, b=13,c=-3,d=8;
    int *bb,**cc;
    bb=&a;
    cc=&bb;
    (*bb)++;
    a=5;
    **cc=**cc + 4;
    cc=&d;
    printf("%d",*bb);
    */
    //char * b="3456789";
    //char * p = b;
    //p+=5;
    //printf("%s%s",p,b);


    //mostrar_archivo();

    //printf("%c",x('u'));
/*
    char a;
    a=((((1)<<(1<<2))>>4)&255)<<7;
    printf("\n%d\n",a);

*/


 /*   char * b="12345";
    char * p=b;
    int i;
    for(i=0;*(p+i)!='\0';p++);
    printf("\n%s%s\n",p,b);


    printf("Es palindroma %d",es_palindromo("arara"));
    return 0;
*/

   /* unsigned int i =0;
    for(i=1;i<10;i=i<<1){
        printf("%d",i);
    }*/

 //   printf("%c",x('A'));
  /*  unsigned char a;
    a=~((~0)<<(1<<2));
    printf("%c",a);
*/
    //printf("%d",retorno(2));

/*
    int a[]={1,3,5,7,9,0};
    int* uno=NULL,dos=0;
    uno=a;
    dos=*(uno+*uno);
    printf("dos:%d\n",dos);
*/
    char nombre[]="3456789"; //DIFERENCIA ENTRE char * y char []
    char * p= nombre+5;
    int i=0;
    while(*(nombre+i)!='\0')
        i++;

    while(i>0 && *p<'9'){

        i--;
        *p=*p+1;
    }


    printf("%s%s",p,nombre);

    //printf("%c",x('a'));
    return 0;
}
void mostrar_archivo(){

    int caract,num;
    FILE * ptrArchivo= fopen("numeros.csv","r");

    if(ptrArchivo!=NULL){

        caract=fgetc(ptrArchivo);
        while(caract!=','){

            if(caract!=EOF){

                while(caract!=','){
                    printf("%c",caract);
                    caract=fgetc(ptrArchivo);
                }

                fscanf(ptrArchivo,"%d\n",&num);
                printf("%d\n",num);

            }

        }


    }





}


char x(char a){

    if(a<'b')
        printf("%c",x(a+1));
        return 'a';

    if('a'>='b')
        return 'b';

}
int doble(int valor){

    int entero=16;
    entero=(valor<<20)&16;



    return entero;

}
int es_palindromo(char* palabra){

    int i,ini,fin,res=1;

    for(i=0;*(palabra+i)!='\0';i++);

    ini=0;
    fin=i-1;
    while(ini!=fin){

        if(*(palabra+ini)==*(palabra+fin)){
            res=0;
        }
        ini++;
        fin--;

    }

    return res;

}
int retorno(int valor){

    if(valor!=(valor&valor)){

        retorno(valor&valor);
        if(valor!=1)
            return 144;
    }

    return 266;

}
void recursiva(char * nombre,int i){
    char aux;
    if(*nombre!='\0'){
        recursiva(nombre+1,i+1);
        if(*nombre>'a' && *nombre<'z'){
            *nombre=65;
        }
        else{
            *nombre=*nombre&255;
        }
    }

}
