#include <stdio.h>
#include <stdlib.h>
char x(char a);
int foo(unsigned char n,unsigned char filter);
int main()
{
    //printf("%c",x('y'));
    /*,c=-3,d=8;
    int *bb, **cc;
    bb=&a;
    cc=&bb;
    (*bb)++;
    **cc=**cc+4;
    *cc= &d;
    printf("%d",*bb); */

   /* int a=9,b=13;

    int* ar[2];
    ar[0]=&a;
    ar[1]=&b;
    printf("%d",*ar[0]+*ar[1]);
*/
  /*  unsigned int i;
    unsigned char a=1;
    for(i=0;i<8;i++){
        a=a&(1<<i);
    }
    printf("%d",a);
*/
   /* char * s[5];int i=0;
    char c='2';
    s[i]=&c;
    for(i=0;i<5;i++){
        s[i]=&c;
        c=c+1;
        printf("%c",c);
    }
    printf("\n%c\n",c);
    printf("(%d,%d)",(c=='2'),!(s[0]==&c));

    printf("\n%d\n",foo(3,4));
*/

    char * s= NULL;
    s="hola";
    printf("%s",s);
    printf("%s",s+2);

    //int j;
    //for(j=0;j<4;j++){
      //  *(s+j)='a'+j;

    //}
    //s[j]='\0';


    return 0;
}

char x(char a){
    if(a>'w')
        printf("%c",x(a-1));
    return 'w';
}

int foo(unsigned char n,unsigned char filter){
    return n&((255&(filter<<n+n))>1);

}
