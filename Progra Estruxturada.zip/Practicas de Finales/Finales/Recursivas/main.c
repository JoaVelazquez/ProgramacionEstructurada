 #include <stdio.h>
#include <stdlib.h>
void ordenarArreglo(int ** arreglo);
void ordenarCadCaracters(int* arr);
int * minArreglo(int * arreglo);
int main()
{
    int arr[]={4,7,2,9,0};
    //int * min=minArreglo(arr);
    //printf("Hello world %d\n",*(min));
    for(int i=0; arr[i]!=0;i++){
        printf("%d\n",arr[i]);
    }


    ordenarArreglo(&arr);
    for(int i=0; arr[i]!=0;i++){
        printf("%d\n",arr[i]);
    }

    return 0;
}

int * minArreglo(int * arreglo){
    int * actual= arreglo;
    int* min= NULL;

    if(*(actual)!=0){
        min= minArreglo(arreglo+1);

        if(min==NULL){
            return actual;
        }
        if( *(actual) < *(min)){
            return actual;
        }
        else{
            return min;
        }

    }
    else{
        return NULL;
    }
}

void ordenarCadCaracters(int* arr){
    int * min= minArreglo(arr) ;
    int actual = *(arr);
    int var;

    if(min!= NULL){
        var = *(min);
        *(arr) = var;
        *(min) = actual;

        ordenarCadCaracters(arr+1);
    }
}
void ordenarArreglo(int ** arreglo){
    int aux;
    int j=0;
    for(int i=0; *(*arreglo+i)!=0;i++){
        for(j= i+1;*(*arreglo+j)!=0;j++){
            if(*(*arreglo +j)>*(*arreglo+i)){

                aux= *(*arreglo+i);
                *(*arreglo+i)=*(*arreglo+j);
                *(*arreglo+j)=aux;
            }
        }
    }




}
