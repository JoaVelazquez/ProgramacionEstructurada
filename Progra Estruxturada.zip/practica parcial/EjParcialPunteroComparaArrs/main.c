#include <stdio.h>
#include <stdlib.h>

void Cargar( int ** arr );
void Imprime( int ** arr );
void DifSimetrica( int * a, int * b, int ** arr );
void UnionDeArr( int * a, int * b, int ** arr );
void InterseccionDeArr( int * a, int * b, int ** arr );
int EstaEnLista( int * arr, int num);


int main()
{
    int * arrA = NULL, arrB = NULL;
    printf("CARGA A: \n");
    Cargar(&arrA);
    Imprime(&arrA);

    printf("\nCARGA B: \n");
    Cargar(&arrB);
    Imprime(&arrB);

    int * DifSim = NULL;
    DifSimetrica(arrA,arrB,&DifSim);
    printf("\nDIF SIMETRICA: \n");
    Imprime(&DifSim);

    int * Union = NULL;
    UnionDeArr(arrA,arrB,&Union);
    printf("\nUNION: \n");
    Imprime(&Union);

    int * Inter = NULL;
    InterseccionDeArr(arrA,arrB,&Inter);
    printf("\nINTERSECCION:\n");
    Imprime(&Inter);



    return 0;
}
void InterseccionDeArr( int * a, int * b, int ** arr ){

    *arr = malloc(sizeof(int));
    int i,j=0;

    for ( i = 0 ; *(a+i)!= 0 ; i++){
        if ( EstaEnLista(b,*(a+i))==1){

            *((*arr)+j) = *(a+i);
            j++;
            *arr = realloc(*arr, (j+1)*sizeof(int));

        }
    }
    for ( i = 0 ; *(b+i)!= 0 ; i++){
        if ( EstaEnLista(a,*(b+i))==1 && EstaEnLista(arr,*(b+i)==0 )){

            *((*arr)+j) = *(b+i);
            j++;
            *arr = realloc(*arr, (j+1)*sizeof(int));

        }
    }

    *((*arr)+j) = 0;

}
void UnionDeArr( int * a, int * b, int ** arr ){

    *arr = malloc( sizeof(int));
    int i;
    int j=0;

    for( i = 0 ; *(a+i)!=0 ; i++ ){
        if( EstaEnLista(*arr, *(a+i))==0 ){
            *((*arr)+j) = *(a+i);
            j++;
            *arr = realloc(*arr, (j+1)*sizeof(int));
        }
    }
    for( i = 0 ; *(b+i)!=0 ; i++ ){
        if( EstaEnLista(*arr, *(b+i))==0 ){
            *((*arr)+j) = *(b+i);
            j++;
            *arr = realloc(*arr, (j+1)*sizeof(int));
        }
    }

    *((*arr)+j) = 0;

}


void DifSimetrica( int * a, int * b, int ** arr ){

    *arr = malloc(sizeof(int));
    int j = 0;
    int i;
    for(i = 0 ; *(a+i)!=0 ; i++){

        if( EstaEnLista(b,*(a+i)) == 0){
            *((*arr)+j) = *(a+i);
            j++;
            *arr = realloc(*arr, (j+1)*sizeof(int));

        }
    }

    for(i = 0 ; *(b+i)!=0; i++){
        if( EstaEnLista(a,*(b+i)) == 0){
            *((*arr)+j) = *(b+i);
            j++;
            *arr = realloc(*arr, (j+1)*sizeof(int));

        }
    }
    *((*arr)+j) = 0;
}

int EstaEnLista( int * arr, int num){

    for ( int i = 0 ; *(arr+i)!=0 ; i++){
        if( *(arr+i) == num){
            return 1;
        }
    }
    return 0;

}
void Cargar( int ** arr ){

    *arr = malloc( sizeof(int));
    int i=0;
    int num;
    printf("\nIngrese los valores del arreglo y finalice con '0': \n");
    scanf("%d",&num);

    while(  num!=0 ){

        *((*arr)+i) = num;
        i++;
        *arr = realloc( *arr, (i+1)*sizeof(int) );
        scanf("%d",&num);

    }
    *((*arr)+i) = 0;

}

void Imprime( int ** arr ){

    printf("\n{  ");
    int i;

    for ( i = 0 ; *((*arr)+i)!=0 ; i++){

        printf("%-3d",*((*arr)+i));

    }
    printf("}\n");

}

