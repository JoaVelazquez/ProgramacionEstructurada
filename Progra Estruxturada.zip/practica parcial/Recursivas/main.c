#include <stdio.h>
#include <stdlib.h>

int esImpar( int num);
int esPar( int num);
int * maxDirR( int * arr);
void invertirR( int * arr, int tam);

int main()
{
    int * arr = {5,4,9,12,6};

    return 0;
}
int maxArrR( int * arr, int tam){



}

int esPar( int num){

    if(num%2 == 0){
        return 1;
    }
    return 0;
}

int esImpar( int num){

    if(num%2 == 0){
        return 0;
    }
    return 1;
}
