#include <stdio.h>
#include <stdlib.h>
#include <math.h>

struct s_datos{

    char nombre[25];
    int matricula,anio;

};
typedef struct s_datos t_datos;

int DevuelveAnio(int num);
int DevuelveMatricula(int num);
void CargarArchEnArr( t_datos arr[], char nombre[], int tam );
void ImprimeArr( t_datos arr[] , int tam);
void Intercambia(t_datos datos[], t_datos cambios[]);

int main()
{
    t_datos datos[4] = {{0}};
    t_datos cambios[2] = {{0}};

    printf("ARR DATOS\n================================\n\n");
    CargarArchEnArr(datos,"datos.txt", 4);
    ImprimeArr(datos,4);

    printf("ARR CAMBIOS\n================================\n\n");
    CargarArchEnArr(cambios,"cambios.txt", 2);
    ImprimeArr(cambios,2);

    printf("ARR CAMBIOS NUEVA\n================================\n\n");
    Intercambia(datos,cambios);
    ImprimeArr(datos,4);


    return 0;
}
void Intercambia(t_datos datos[], t_datos cambios[]){

    int f;

    for( f=0 ; f<4 ; f++){
        if( datos[f].matricula == cambios[0].matricula ){
            datos[f] = cambios[1];
        }
    }

}
void CargarArchEnArr( t_datos arr[], char nombre[], int tam ){


    FILE* arch;
    arch = fopen( nombre, "r");
    if( arch == NULL ){

        printf("El archivo esta vacio!");

    }
    else{
        int f,i,num;
        char c;
        for( f=0 ; f<tam && c!=EOF ; f++ ){
            c = fgetc(arch);
            for( i=0 ; c!=',' && c!=EOF ; i++){
                arr[f].nombre[i] = c;
                c = fgetc(arch);
            }
            fscanf(arch , "%d\n" , &num);
            arr[f].anio = DevuelveAnio(num);
            arr[f].matricula = DevuelveMatricula(num);

        }
    }

    fclose(arch);

}

int DevuelveAnio(int num){

    unsigned int mask = pow(2,16)-1;

    return num = num&mask;
}
int DevuelveMatricula(int num){

    unsigned int mask = pow(2,16)-1;

    return num = (num>>16)&mask;
}

void ImprimeArr( t_datos arr[] , int tam){

    int i;
    for ( i=0 ; i<tam ; i++ ){

        printf("\n%s\t",arr[i].nombre);
        printf("%5d",arr[i].anio);
        printf("%5d\n",arr[i].matricula);

    }
    printf("\n");

}
