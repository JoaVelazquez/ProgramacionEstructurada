#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

struct s_datos{

    char nombre[50];
    int matricula;
    int anio;

};
typedef struct s_datos t_datos;

int DevuelveAnio(int numeroBin);
int DevuelveMat(int numeroBin);
void CargaStruct(t_datos arr[3], char nombre[],int tam);
void Cambia(t_datos A[], t_datos B[]);
void ImprimeArr(t_datos arr[], int tam);


int main()
{
    t_datos arr_datos[4] = {0};
    t_datos arr_cambios[2] = {0};


    printf("Carga arreglo de datos.\n\n");
    CargaStruct(arr_datos,"datos.txt",4);
    ImprimeArr(arr_datos,4);


    printf("\n---------------------\n\n");


    printf("Carga arreglo de datos.\n\n");
    CargaStruct(arr_cambios,"cambios.txt",2);
    ImprimeArr(arr_cambios,2);


    printf("\n---------------------\n\n");


    printf("Realiza Cambios\n\n");
    Cambia(arr_datos,arr_cambios);
    ImprimeArr(arr_datos,4);

    return 0;
}
void Cambia(t_datos A[], t_datos B[]){

    int f;
    for( f=0 ; f<4 ; f++){
        if ( (A[f].matricula == B[0].matricula)){
            A[f] = B[1];
        }
    }

}
void CargaStruct(t_datos arr[], char nombre[],int tam){

    char c;
    FILE* arch;
    arch = fopen( nombre, "r");
    if( arch == NULL ){
        printf("ERROR! El archivo esta vacio");
    }else{
        int f=0,i=0,numero=0;

        for( f = 0 ; (f < tam) && (c!=EOF) ; f++){
            c = fgetc(arch);
            for( i = 0 ; (c!=',') && (c!= EOF) ; i++){

                arr[f].nombre[i] = c;
                c = fgetc(arch);

            }

            fscanf(arch,"%d\n",&numero);
            arr[f ].anio = DevuelveAnio(numero);
            arr[f].matricula = DevuelveMat(numero);


        }
        fclose(arch);
    }
}

void ImprimeArr(t_datos arr[], int tam){

    int i;
    for( i = 0 ; i < tam ; i++){

        printf("%s\t",arr[i].nombre);
        printf("%5d",arr[i].anio);
        printf("%5d\n",arr[i].matricula);
    }

}
int DevuelveAnio(int numeroBin){

    unsigned int mask = pow(2,16) - 1;
    int anio = numeroBin & mask;
    return anio;
}
int DevuelveMat(int numeroBin){

    unsigned int mask = pow(2,16) - 1;
    int mat = numeroBin>>16 & mask;
    return mat;
}
