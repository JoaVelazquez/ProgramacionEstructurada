#include <stdio.h>
#include <stdlib.h>
#include <math.h>

struct s_datos{

    char nombre[50];
    int matricula;
    int anio;

};
typedef struct s_datos t_datos;

int DevuelveMatricula(int valor);
int DevuelveAnio(int valor);
void CargaArchEnArr( t_datos arr[], char nombre[], int tam );

int main()
{
    t_datos datos[4] = {0};
    t_datos cambios[2] = {0};

    printf("ARREGLO DATOS \n===============================\n\n");
    CargaArchEnArr(datos, "datos.txt" , 4);
    ImprimeArr(datos,4);

    printf("\n\nARREGLO CAMBIOS \n===============================\n\n");
    CargaArchEnArr(cambios, "cambios.txt" , 2);
    ImprimeArr(cambios,2);

    intercambia(datos,cambios);
    printf("\n\nARREGLO DATOS NUEVO \n===============================\n\n");
    ImprimeArr(datos,4);


    return 0;
}

void CargaArchEnArr( t_datos arr[], char nombre[], int tam ){

    FILE* arch;
    arch = fopen( nombre, "r" );
    if( arch == NULL ){
        printf("El archivo esta vacio!");
    }
    else{
            int f,i,valor;
        char c;
        for ( f = 0 ; (c!=EOF) && (f<tam) ; f++ ){
            c = fgetc(arch);
            for( i = 0 ; (c!=',') && (c!=EOF) ; i++){

                arr[f].nombre[i] = c;
                c = fgetc(arch);

            }

            fscanf( arch, "%d\n" , &valor);
            (arr[f]).anio = DevuelveAnio(valor);
            (arr[f]).matricula = DevuelveMatricula(valor);
            //printf("%s\n",arr[f].nombre);
        }

    }
    fclose(arch);

}
void intercambia( t_datos datos[], t_datos cambios[]) {

    int f;
    for ( f = 0 ; f<4 ; f++ ){

        if ( datos[f].matricula == cambios[0].matricula ){

            datos[f] = cambios[1];

        }

    }

}

void ImprimeArr( t_datos arr[] , int tam){

    int f;
    for( f = 0 ; f<tam ; f++){
        printf("\n>>Pasche puto<<\n");
        printf("%s\t",arr[f].nombre);
        printf("%5d",arr[f].anio);
        printf("%5d\n",arr[f].matricula);

    }


}
int DevuelveAnio(int valor){

    unsigned int mask = pow(2,16)-1;
    return valor = valor & mask;
}
int DevuelveMatricula(int valor){

    unsigned int mask = pow(2,16)-1;
    return valor = (valor>>16) & mask;

}
