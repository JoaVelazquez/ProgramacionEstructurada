#include <stdio.h>
#include <stdlib.h>
#include <math.h>


struct s_datos{

    char nombre[50];
    int matricula;
    int anio;

};
typedef struct s_datos t_datosl;
int DevuelveAnio(int numeroBin);

int main()
{
    printf("%d",DevuelveAnio(73991124));
//    printf("%d",DevuelveMat(73991124));
    return 0;
}
int DevuelveAnio(int numeroBin){

    //printf("%d\n",pow(256,2));
    unsigned int mask = (pow(2,16))-1;
    int anio = numeroBin & mask;



}
