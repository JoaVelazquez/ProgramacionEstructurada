#include <stdio.h>
#include <stdlib.h>

int productoR(int a, int b);
char imprimeArrCR( char* arrC );
char imprimeRevesArrCR( char* arrC );
int DivisionR(int a, int b);
float PotenciaR(float a, float b);
int RestoRecursivo(int a,int b);
int RangoR(int a, int b);
int esImpar( int num);
int esPar( int num);
int * maxNumArr( int * arr);
int * minNumArr( int * arr);
int * maxDirR( int * arr);
int * minDirR( int * arr);
void Imprime( int ** arr );
void Cargar( int ** arr );
int esVocal( char c );

int main()
{

    /*printf("%d", productoR(4,3));*/
    char arrC[5] = "Hola";
    printf("La cantidad de vocales en la palabra es : %d\n",cuentaVocalesR(arrC));
    /*
    imprimeArrCR(arrC);
    printf("\n");
    imprimeRevesArrCR(arrC);
    printf("%d",DivisionR(9,3));
    printf("%d",RestoRecursivo(5,2));
    printf("%.0f",PotenciaR(4,5));
    printf("%d", RangoR(1,5));
    int * arrA = NULL, arrB = NULL;
    printf("CARGA A: \n");
    Cargar(&arrA);
    Imprime(&arrA);
    printf("Val Maximo del arreglo: %d\n",maxNumArr(arrA));
    printf("Val Minimo del arreglo: %d\n",minNumArr(arrA));
    printf("Dir maxima en el arreglo:%d\n",maxDirR(arrA));
    printf("Dir minima en el arreglo:%d\n",minDirR(arrA));*/

    return 0;
}
int cuentaVocalesR( char * palabra){

    if ( *palabra!='\0' ){
        if( esVocal(*palabra)){
            return 1+ cuentaVocalesR(palabra+1);
        }else{
            return cuentaVocalesR(palabra+1);
        }
    }else{
    return 0;

    }
}
int esVocal( char c ){

    char vocales[10] = {'a','e','i','o','u','A','E','I','O','U'};
    for ( int i = 0 ; i<10 ; i++){
        if( c==vocales[i]){
            return 1;
        }
    }
    return 0;
}
int * minDirR( int * arr){
    int minDir = arr;

    if ( *arr != 0 && *(arr+1) != 0 ){
        int minDirSig = minDirR(arr+1);
        if ( minDirSig < minDir ){
            minDir = minDirSig;
        }
    }
    return minDir;

}
int * maxDirR( int * arr){
    int maxDir = arr;

    if ( *arr != 0 && *(arr+1) != 0 ){
        int maxDirSig = maxDirR(arr+1);
        if ( maxDirSig > maxDir ){
            maxDir = maxDirSig;
        }
    }
    return maxDir;

}
int * minNumArr( int * arr){
    int min = *arr;

    if ( *arr != 0 && *(arr+1) != 0){
        int minSig = minNumArr(arr+1);
        if ( minSig < min ){
            min = minSig;
        }
    }
    return min;

}

int * maxNumArr( int * arr){

    int max = *arr;

    if ( *arr!=0 && *(arr+1)!=0 ){
        int maxSig = maxNumArr(arr+1);
        if ( maxSig > max ){
            max = maxSig;
        }
    }
    return max;
}

int RangoR(int a, int b){

    if( (b-a)>=0){
        return a+RangoR(a+1,b);
    }
    return 0;

}
float PotenciaR(float a, float b){

    if( b>1 ){
        return a*(PotenciaR(a,b-1));
    }
    return 1;
}
int RestoRecursivo(int a,int b){

    if ( a >= b ){
         return RestoRecursivo(a-b,b);
    }
    return a;

}
int DivisionR(int a, int b){

    if( a>=b ){
        return 1+DivisionR( a-b, b);

    }
    return 0;
}
int productoR(int a, int b){

    if ( b > 0 ){
        return a+productoR(a,b-1);
    }
    return 0;
}
char imprimeArrCR( char* arrC ){

    if( *arrC!='\0' ){
    int * minDirR( int * arr);
        printf("%c",*arrC);
        imprimeArrCR( arrC+1 );
    }int * minDirR( int * arr);
}
char imprimeRevesArrCR( char* arrC ){

    if( *arrC!='\0' ){

        imprimeArrCR( arrC+1 );
        printf("%c",*arrC);
    }

}
int esPar( int num){

    if(num%2 == 0){
        return 1;
    }int * maxNumArr( int * arr);
    return 0;
}

int esImpar( int num){

    if(num%2 == 0){
        return 0;
    }
    return 1;
}
void Cargar( int ** arr ){

    *arr = malloc( sizeof(int));
    int i=0;
    int num;
    printf("\nIngrese los valores del arreglo y finalice con '0': \n");
    scanf("%d",&num);

    while(  num!=0 ){

        *((*arr)+i) = num;
        i++;
        *arr = realloc( *arr, (i+1)*sizeof(int) );
        scanf("%d",&num);

    }
    *((*arr)+i) = 0;

}
void Imprime( int ** arr ){

    printf("\n{  ");
    int i;

    for ( i = 0 ; *((*arr)+i)!=0 ; i++){

        printf("%-3d",*((*arr)+i));

    }
    printf("}\n");

}


